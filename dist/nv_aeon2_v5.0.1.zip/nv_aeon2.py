"""Aeon Timeline 2 sync plugin for novelibre.

Version 5.0.1
Requires Python 3.6+
Copyright (c) 2024 Peter Triesberger
For further information see https://github.com/peter88213/nv_aeon2
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
from datetime import datetime
import os
from pathlib import Path
from tkinter import filedialog
from tkinter import messagebox
from tkinter import ttk
import webbrowser


from datetime import datetime
from datetime import timedelta

from abc import ABC
from urllib.parse import quote

from calendar import day_name
from calendar import month_name
from datetime import date
from datetime import time
import gettext
import locale
import sys

ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
GRID_SUFFIX = '_grid_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PROJECTNOTES_SUFFIX = '_projectnote_report'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
XREF_SUFFIX = '_xref'


class Error(Exception):
    pass


class Notification(Error):
    pass


try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation('novelibre', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
        _ = t.gettext
    except:

        def _(message):
            return message

WEEKDAYS = day_name
MONTHS = month_name


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_date(dateStr):
    if dateStr is not None:
        date.fromisoformat(dateStr)
    return dateStr


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr


def verified_time(timeStr):
    if  timeStr is not None:
        time.fromisoformat(timeStr)
        while timeStr.count(':') < 2:
            timeStr = f'{timeStr}:00'
    return timeStr



class File(ABC):
    DESCRIPTION = _('File')
    EXTENSION = None
    SUFFIX = None

    def __init__(self, filePath, **kwargs):
        self.novel = None
        self._filePath = None
        self.projectName = None
        self.projectPath = None
        self.sectionsSplit = False
        self.filePath = filePath

    @property
    def filePath(self):
        return self._filePath

    @filePath.setter
    def filePath(self, filePath: str):
        filePath = filePath.replace('\\', '/')
        if self.SUFFIX is not None:
            suffix = self.SUFFIX
        else:
            suffix = ''
        if filePath.lower().endswith(f'{suffix}{self.EXTENSION}'.lower()):
            self._filePath = filePath
            try:
                head, tail = os.path.split(os.path.realpath(filePath))
            except:
                head, tail = os.path.split(filePath)
            self.projectPath = quote(head.replace('\\', '/'), '/:')
            self.projectName = quote(tail.replace(f'{suffix}{self.EXTENSION}', ''))

    def is_locked(self):
        return False

    def read(self):
        raise NotImplementedError

    def write(self):
        raise NotImplementedError



def new_id(elements, prefix=''):
    i = 1
    while f'{prefix}{i}' in elements:
        i += 1
    return f'{prefix}{i}'

import codecs
from json import JSONDecodeError
import json
import zipfile


LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('nv_aeon2', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message



def open_timeline(filePath):
    try:
        with zipfile.ZipFile(filePath, 'r') as myzip:
            jsonBytes = myzip.read('timeline.json')
            jsonStr = codecs.decode(jsonBytes, encoding='utf-8')
    except:
        raise Error(f'{_("Cannot read timeline data")}.')
    if not jsonStr:
        raise Error(f'{_("No JSON part found in timeline data")}.')
    try:
        jsonData = json.loads(jsonStr)
    except JSONDecodeError:
        raise Error(f'{_("Invalid JSON data in timeline")}.')
    return jsonData


def save_timeline(jsonData, filePath):
    backedUp = False
    if os.path.isfile(filePath):
        try:
            os.replace(filePath, f'{filePath}.bak')
        except:
            raise Error(f'{_("Cannot overwrite file")}: "{norm_path(filePath)}".')
        else:
            backedUp = True
    try:
        with zipfile.ZipFile(filePath, 'w', compression=zipfile.ZIP_DEFLATED) as f:
            f.writestr('timeline.json', json.dumps(jsonData))
    except:
        if backedUp:
            os.replace(f'{filePath}.bak', filePath)
        raise Error(f'{_("Cannot write file")}: "{norm_path(filePath)}".')

import uuid


class GuidGenerator:

    def __init__(self, filePath):
        self._url = f'file:///{filePath}'

    def get_guid(self, fragment):
        return str(uuid.uuid3(uuid.NAMESPACE_URL, f'{self._url}#{fragment}'))


class JsonTimeline2(File):
    EXTENSION = '.aeonzip'
    DESCRIPTION = _('Aeon Timeline 2 project')
    SUFFIX = ''
    DATE_LIMIT = (datetime(1, 1, 1) - datetime.min).total_seconds()

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath, **kwargs)
        self._nvSvc = kwargs['nv_service']



        url = f'{self.projectName}'
        self._guidGen = GuidGenerator(url)

        self._jsonData = None

        self._entityNarrative = kwargs['narrative_arc']

        self._propertyDesc = kwargs['property_description']
        self._propertyNotes = kwargs['property_notes']
        self._propertyMoonphase = kwargs['property_moonphase']

        self._roleArc = kwargs['role_arc']
        self._rolePlotline = kwargs['role_plotline']
        self._roleCharacter = kwargs['role_character']
        self._roleLocation = kwargs['role_location']
        self._roleItem = kwargs['role_item']

        self._typeArc = kwargs['type_arc']
        self._typeCharacter = kwargs['type_character']
        self._typeLocation = kwargs['type_location']
        self._typeItem = kwargs['type_item']

        self._tplDateGuid = None
        self._typeArcGuid = None
        self._typeCharacterGuid = None
        self._typeLocationGuid = None
        self._typeItemGuid = None
        self._roleArcGuid = None
        self._rolePlotlineGuid = None
        self._roleCharacterGuid = None
        self._roleLocationGuid = None
        self._roleItemGuid = None
        self._entityNarrativeGuid = None
        self._propertyDescGuid = None
        self._propertyNotesGuid = None
        self._propertyMoonphaseGuid = None

        self.referenceDate = None
        self._addMoonphase = kwargs['add_moonphase']
        self._sectionColor = kwargs['color_section']
        self._eventColor = kwargs['color_event']
        self._timestampMax = 0
        self._displayIdMax = 0.0
        self._colors = {}
        self._arcCount = 0
        self._characterGuidsById = {}
        self._locationGuidsById = {}
        self._itemGuidsById = {}
        self._arcGuidsById = {}
        self._trashEvents = []

    def read(self):
        self._set_reference_date(self.novel)
        self._jsonData = open_timeline(self.filePath)

        self._r_fetch_color_definitions()
        self._r_fetch_date_definition()
        self._r_fetch_arc_type_and_roles_guid()
        self._r_fetch_character_type_and_roles_guid()
        self._r_fetch_location_type_and_roles_guid()
        self._r_fetch_item_type_and_roles_guid()
        self._r_fetch_property_moonphase_guid()
        self._r_fetch_property_notes_guid()
        self._r_fetch_property_desc_guid()


        self._r_check_source_characters()
        self._r_check_source_locations()
        self._r_check_source_items()
        self._r_check_source_arcs()

        targetScIdsByTitle = self._r_check_target_sections()
        targetCrIdsByTitle = self._r_check_target_characters()
        targetItIdsByTitle = self._r_check_target_items()
        targetLcIdsByTitle = self._r_check_target_locations()
        targetAcIdsByTitle = self._r_check_target_arcs()

        crIdsByGuid = self._r_fetch_character_guids_by_id(targetCrIdsByTitle)
        lcIdsByGuid = self._r_fetch_location_guids_by_id(targetLcIdsByTitle)
        itIdsByGuid = self._r_fetch_item_guids_by_id(targetItIdsByTitle)
        acIdsByGuid = self._r_fetch_arc_guids_by_id(targetAcIdsByTitle)

        if not self._entityNarrativeGuid:
            return

        narrativeEvents, scIdsByDate = self._r_update_or_create_sections(
            targetScIdsByTitle,
            crIdsByGuid,
            lcIdsByGuid,
            itIdsByGuid,
            acIdsByGuid
            )

        self._r_make_sections_deleted_in_aeon_unused(narrativeEvents)
        self._r_put_new_sections_into_new_chapter(scIdsByDate)
        self._r_adjust_timestamp()

    def write(self, source):
        self._set_reference_date(source)


        relatedCharacters, relatedLocations, relatedItems, relatedArcs = self._w_get_related_elements(source)

        self._w_check_source_characters(source, relatedCharacters)
        self._w_check_source_locations(source, relatedLocations)
        self._w_check_source_items(source, relatedItems)
        self._w_check_source_arcs(source, relatedArcs)

        srcScnTitles = self._w_check_source_sections(source)
        self._w_collect_trashed_sections(srcScnTitles)

        scIdsByTitle = self._w_check_target_sections()
        crIdsByTitle = self._w_check_target_characters()
        lcIdsByTitle = self._w_check_target_locations()
        itIdsByTitle = self._w_check_target_items()
        acIdsByTitle = self._w_check_target_arcs()

        self._w_create_json_type_character_if_missing()
        self._w_create_json_type_location_if_missing()
        self._w_create_json_type_item_if_missing()
        self._w_create_json_type_arc_if_missing()
        self._w_create_json_role_arc_if_missing()
        self._w_create_json_role_character_if_missing()
        self._w_create_json_role_location_if_missing()
        self._w_create_json_role_item_if_missing()
        self._w_create_json_role_plotline_if_missing()
        self._w_create_json_property_notes_if_missing()
        self._w_create_json_property_desc_if_missing()
        self._w_create_json_property_moonphase_if_missing()

        crIdsBySrcId = self._w_update_characters_from_source(source,
            crIdsByTitle,
            relatedCharacters
            )
        lcIdsBySrcId = self._w_update_locations_from_source(source,
            lcIdsByTitle,
            relatedLocations
            )
        itIdsBySrcId = self._w_update_items_from_source(source,
            itIdsByTitle,
            relatedItems
            )
        acIdsBySrcId = self._w_update_arcs_from_source(source,
            acIdsByTitle,
            relatedArcs
            )
        self._w_update_sections_from_source(source,
            scIdsByTitle,
            crIdsBySrcId,
            lcIdsBySrcId,
            itIdsBySrcId,
            acIdsBySrcId
            )


        self._w_create_json_narrative_arc_if_missing()
        self._w_update_json_events_from_sections(scIdsByTitle)
        self._w_delete_trashed_events(scIdsByTitle)

        save_timeline(self._jsonData, self.filePath)

    def _r_adjust_timestamp(self):
        if self._timestampMax == 0:
            self._timestampMax = (self.referenceDate - datetime.min).total_seconds()

    def _r_check_source_arcs(self):
        arcNames = []
        for entity in self._jsonData['entities']:
            if entity['entityType'] != self._typeArcGuid:
                continue

            if entity['name'] in arcNames:
                raise Error(_('Ambiguous Aeon arc "{}".').format(entity['name']))

            arcNames.append(entity['name'])

    def _r_check_source_characters(self):
        characterNames = []
        for entity in self._jsonData['entities']:
            if entity['entityType'] != self._typeCharacterGuid:
                continue

            if entity['name'] in characterNames:
                raise Error(_('Ambiguous Aeon character "{}".').format(entity['name']))

            characterNames.append(entity['name'])

    def _r_check_source_items(self):
        itemNames = []
        for entity in self._jsonData['entities']:
            if entity['entityType'] != self._typeItemGuid:
                continue

            if entity['name'] in itemNames:
                raise Error(_('Ambiguous Aeon item "{}".').format(entity['name']))

            itemNames.append(entity['name'])

    def _r_check_source_locations(self):
        locationNames = []
        for entity in self._jsonData['entities']:
            if entity['entityType'] != self._typeLocationGuid:
                continue

            if entity['name'] in locationNames:
                raise Error(_('Ambiguous Aeon location "{}".').format(entity['name']))

            locationNames.append(entity['name'])

    def _r_check_target_arcs(self):
        targetAcIdsByTitle = {}
        for acId in self.novel.plotLines:
            title = self.novel.plotLines[acId].title
            if title:
                if title in targetAcIdsByTitle:
                    raise Error(_('Ambiguous novelibre plot line "{}".').format(title))

                targetAcIdsByTitle[title] = acId
        return targetAcIdsByTitle

    def _r_check_target_characters(self):
        targetCrIdsByTitle = {}
        for crId in self.novel.characters:
            title = self.novel.characters[crId].title
            if title:
                if title in targetCrIdsByTitle:
                    raise Error(_('Ambiguous novelibre character "{}".').format(title))

                targetCrIdsByTitle[title] = crId
        return targetCrIdsByTitle

    def _r_check_target_items(self):
        targetItIdsByTitle = {}
        for itId in self.novel.items:
            title = self.novel.items[itId].title
            if title:
                if title in targetItIdsByTitle:
                    raise Error(_('Ambiguous novelibre item "{}".').format(title))

                targetItIdsByTitle[title] = itId
        return targetItIdsByTitle

    def _r_check_target_locations(self):
        targetLcIdsByTitle = {}
        for lcId in self.novel.locations:
            title = self.novel.locations[lcId].title
            if title:
                if title in targetLcIdsByTitle:
                    raise Error(_('Ambiguous novelibre location "{}".').format(title))

                targetLcIdsByTitle[title] = lcId
        return targetLcIdsByTitle

    def _r_check_target_sections(self):
        targetScIdsByTitle = {}
        for scId in self.novel.sections:
            title = self.novel.sections[scId].title
            if title:
                if title in targetScIdsByTitle:
                    raise Error(_('Ambiguous novelibre section title "{}".').format(title))

                targetScIdsByTitle[title] = scId
        return targetScIdsByTitle

    def _r_fetch_arc_guids_by_id(self, targetAcIdsByTitle):
        acIdsByGuid = {}
        for entity in self._jsonData['entities']:
            if entity['entityType'] != self._typeArcGuid:
                continue

            if entity['name'] in targetAcIdsByTitle:
                plId = targetAcIdsByTitle[entity['name']]
            elif entity['name'] != self._entityNarrative:

                plId = new_id(self.novel.plotLines, prefix=PLOT_LINE_PREFIX)
                self.novel.plotLines[plId] = self._nvSvc.new_plot_line(title=entity['name'], shortName=entity['name'])
                self.novel.tree.append(PL_ROOT, plId)
            if entity['name'] == self._entityNarrative:
                self._entityNarrativeGuid = entity['guid']
            else:
                acIdsByGuid[entity['guid']] = plId
                self._arcGuidsById[plId] = entity['guid']
                self._arcCount += 1
        return acIdsByGuid

    def _r_fetch_arc_type_and_roles_guid(self):
        for tplTyp in self._jsonData['template']['types']:
            if tplTyp['name'] == self._typeArc:
                self._typeArcGuid = tplTyp['guid']
                for tplTypRol in tplTyp['roles']:
                    if tplTypRol['name'] == self._roleArc:
                        self._roleArcGuid = tplTypRol['guid']
                    elif tplTypRol['name'] == self._rolePlotline:
                        self._rolePlotlineGuid = tplTypRol['guid']
                continue

    def _r_fetch_character_guids_by_id(self, targetCrIdsByTitle):
        crIdsByGuid = {}
        for entity in self._jsonData['entities']:
            if entity['entityType'] != self._typeCharacterGuid:
                continue

            if entity['name'] in targetCrIdsByTitle:
                crId = targetCrIdsByTitle[entity['name']]
            else:
                crId = new_id(self.novel.characters, prefix=CHARACTER_PREFIX)
                self.novel.characters[crId] = self._nvSvc.new_character(title=entity['name'])
                self.novel.tree.append(CR_ROOT, crId)
            crIdsByGuid[entity['guid']] = crId
            self._characterGuidsById[crId] = entity['guid']
            if entity['notes']:
                self.novel.characters[crId].notes = entity['notes']
            else:
                entity['notes'] = ''
            createRangePosition = entity.get('createRangePosition', None)
            if createRangePosition:
                timestamp = createRangePosition['timestamp']
                if timestamp >= self.DATE_LIMIT:
                    birthDate = datetime.min + timedelta(seconds=timestamp)
                    self.novel.characters[crId].birthDate = birthDate.isoformat().split('T')[0]
            destroyRangePosition = entity.get('destroyRangePosition', None)
            if destroyRangePosition:
                timestamp = destroyRangePosition['timestamp']
                if timestamp >= self.DATE_LIMIT:  # Restrict date/time calculation to dates within novelibre's range
                    deathDate = datetime.min + timedelta(seconds=timestamp)
                    self.novel.characters[crId].deathDate = deathDate.isoformat().split('T')[0]
        return crIdsByGuid

    def _r_fetch_character_type_and_roles_guid(self):
        for tplTyp in self._jsonData['template']['types']:
            if tplTyp['name'] == self._typeCharacter:
                self._typeCharacterGuid = tplTyp['guid']
                for tplTypRol in tplTyp['roles']:
                    if tplTypRol['name'] == self._roleCharacter:
                        self._roleCharacterGuid = tplTypRol['guid']
                        break
                continue

    def _r_fetch_color_definitions(self):
        for tplCol in self._jsonData['template']['colors']:
            self._colors[tplCol['name']] = tplCol['guid']

    def _r_fetch_date_definition(self):
        for tplRgp in self._jsonData['template']['rangeProperties']:
            if tplRgp['type'] == 'date':
                for tplRgpCalEra in tplRgp['calendar']['eras']:
                    if tplRgpCalEra['name'] == 'AD':
                        self._tplDateGuid = tplRgp['guid']
                        break

        if self._tplDateGuid is None:
            raise Error(_('"AD" era is missing in the calendar.'))

    def _r_fetch_item_guids_by_id(self, targetItIdsByTitle):
        itIdsByGuid = {}
        for entity in self._jsonData['entities']:
            if entity['entityType'] != self._typeItemGuid:
                continue

            if entity['name'] in targetItIdsByTitle:
                itId = targetItIdsByTitle[entity['name']]
            else:
                itId = new_id(self.novel.items, prefix=ITEM_PREFIX)
                self.novel.items[itId] = self._nvSvc.new_world_element()
                self.novel.items[itId].title = entity['name']
                self.novel.tree.append(IT_ROOT, itId)  # Create a new item.
            itIdsByGuid[entity['guid']] = itId
            self._itemGuidsById[itId] = entity['guid']
        return itIdsByGuid

    def _r_fetch_item_type_and_roles_guid(self):
        for tplTyp in self._jsonData['template']['types']:
            if tplTyp['name'] == self._typeItem:
                self._typeItemGuid = tplTyp['guid']
                for tplTypRol in tplTyp['roles']:
                    if tplTypRol['name'] == self._roleItem:
                        self._roleItemGuid = tplTypRol['guid']
                        break
                continue

    def _r_fetch_location_guids_by_id(self, targetLcIdsByTitle):
        lcIdsByGuid = {}
        for entity in self._jsonData['entities']:
            if entity['entityType'] != self._typeLocationGuid:
                continue

            if entity['name'] in targetLcIdsByTitle:
                lcId = targetLcIdsByTitle[entity['name']]
            else:
                lcId = new_id(self.novel.locations, prefix=LOCATION_PREFIX)
                self.novel.locations[lcId] = self._nvSvc.new_world_element()
                self.novel.locations[lcId].title = entity['name']
                self.novel.tree.append(LC_ROOT, lcId)  # Create a new location.
            lcIdsByGuid[entity['guid']] = lcId
            self._locationGuidsById[lcId] = entity['guid']
        return lcIdsByGuid

    def _r_fetch_location_type_and_roles_guid(self):
        for tplTyp in self._jsonData['template']['types']:
            if tplTyp['name'] == self._typeLocation:
                self._typeLocationGuid = tplTyp['guid']
                for tplTypRol in tplTyp['roles']:
                    if tplTypRol['name'] == self._roleLocation:
                        self._roleLocationGuid = tplTypRol['guid']
                        break
                continue

    def _r_fetch_property_desc_guid(self):
        for tplPrp in self._jsonData['template']['properties']:
            if tplPrp['name'] == self._propertyDesc:
                self._propertyDescGuid = tplPrp['guid']
                return

    def _r_fetch_property_moonphase_guid(self):
        for tplPrp in self._jsonData['template']['properties']:
            if tplPrp['name'] == self._propertyMoonphase:
                self._propertyMoonphaseGuid = tplPrp['guid']
                break

    def _r_fetch_property_notes_guid(self):
        for tplPrp in self._jsonData['template']['properties']:
            if tplPrp['name'] == self._propertyNotes:
                self._propertyNotesGuid = tplPrp['guid']
                return

    def _r_make_sections_deleted_in_aeon_unused(self, narrativeEvents):
        for scId in self.novel.sections:
            if scId in narrativeEvents:
                continue

            if self.novel.sections[scId].scType == 0:
                self.novel.sections[scId].scType = 1

    def _r_put_new_sections_into_new_chapter(self, scIdsByDate):
        sectionsInChapters = []
        for chId in self.novel.tree.get_children(CH_ROOT):
            sectionsInChapters.extend(self.novel.tree.get_children(chId))

        newChapterId = new_id(self.novel.chapters, prefix=CHAPTER_PREFIX)
        newChapter = self._nvSvc.new_chapter(title=_('New sections'), chType=0)
        srtSections = sorted(scIdsByDate.items())
        for __, scList in srtSections:
            for scId in scList:
                if not scId in sectionsInChapters:
                    if not newChapterId in self.novel.tree.get_children(CH_ROOT):
                        self.novel.chapters[newChapterId] = newChapter
                        self.novel.tree.append(CH_ROOT, newChapterId)
                    self.novel.tree.append(newChapterId, scId)

    def _r_update_or_create_sections(self, targetScIdsByTitle, crIdsByGuid, lcIdsByGuid, itIdsByGuid, acIdsByGuid):
        scIdsByDate = {}
        scnTitles = []
        narrativeEvents = []
        for event in self._jsonData['events']:

            isNarrative = False
            for evtRel in event['relationships']:
                if evtRel['role'] == self._roleArcGuid:
                    if evtRel['entity'] == self._entityNarrativeGuid:
                        isNarrative = True
                        break

            eventTitle = event['title'].strip()
            if eventTitle in scnTitles:
                raise Error(f'Ambiguous Aeon event title "{event["title"]}".')

            scnTitles.append(eventTitle)

            if eventTitle in targetScIdsByTitle:
                scId = targetScIdsByTitle[eventTitle]
            elif isNarrative:
                scId = new_id(self.novel.sections, prefix=SECTION_PREFIX)
                self.novel.sections[scId] = self._nvSvc.new_section(
                    title=eventTitle,
                    status=1,
                    scType=0,
                    scene=0,
                    )
            else:
                continue

            narrativeEvents.append(scId)
            displayId = float(event['displayId'])
            if displayId > self._displayIdMax:
                self._displayIdMax = displayId

            hasDescription = False
            hasNotes = False
            for evtVal in event['values']:

                if evtVal['property'] == self._propertyDescGuid:
                    hasDescription = True
                    if evtVal['value']:
                        self.novel.sections[scId].desc = evtVal['value']

                elif evtVal['property'] == self._propertyNotesGuid:
                    hasNotes = True
                    if evtVal['value']:
                        self.novel.sections[scId].notes = evtVal['value']

            if not hasDescription:
                event['values'].append({'property': self._propertyDescGuid, 'value': ''})
            if not hasNotes:
                event['values'].append({'property': self._propertyNotesGuid, 'value': ''})

            if event['tags']:
                self.novel.sections[scId].tags = []
                for evtTag in event['tags']:
                    self.novel.sections[scId].tags.append(evtTag)

            timestamp = 0
            for evtRgv in event['rangeValues']:
                if evtRgv['rangeProperty'] == self._tplDateGuid:
                    timestamp = evtRgv['position']['timestamp']
                    if timestamp >= self.DATE_LIMIT:
                        sectionStart = datetime.min + timedelta(seconds=timestamp)
                        startDateTime = sectionStart.isoformat().split('T')

                        if self.novel.sections[scId].day is not None:
                            sectionDelta = sectionStart - self.referenceDate
                            self.novel.sections[scId].day = str(sectionDelta.days)
                        elif (self.novel.sections[scId].time is not None) and (self.novel.sections[scId].date is None):
                            self.novel.sections[scId].day = '0'
                        else:
                            self.novel.sections[scId].date = startDateTime[0]
                        self.novel.sections[scId].time = startDateTime[1]

                        if 'years' in evtRgv['span'] or 'months' in evtRgv['span']:
                            endYear = sectionStart.year
                            endMonth = sectionStart.month
                            if 'years' in evtRgv['span']:
                                endYear += evtRgv['span']['years']
                            if 'months' in evtRgv['span']:
                                endMonth += evtRgv['span']['months']
                                while endMonth > 12:
                                    endMonth -= 12
                                    endYear += 1
                            sectionEnd = datetime(endYear, endMonth, sectionStart.day)
                            sectionDuration = sectionEnd - datetime(sectionStart.year, sectionStart.month, sectionStart.day)
                            lastsDays = sectionDuration.days
                            lastsHours = sectionDuration.seconds // 3600
                            lastsMinutes = (sectionDuration.seconds % 3600) // 60
                        else:
                            lastsDays = 0
                            lastsHours = 0
                            lastsMinutes = 0
                        if 'weeks' in evtRgv['span']:
                            lastsDays += evtRgv['span']['weeks'] * 7
                        if 'days' in evtRgv['span']:
                            lastsDays += evtRgv['span']['days']
                        if 'hours' in evtRgv['span']:
                            lastsDays += evtRgv['span']['hours'] // 24
                            lastsHours += evtRgv['span']['hours'] % 24
                        if 'minutes' in evtRgv['span']:
                            lastsHours += evtRgv['span']['minutes'] // 60
                            lastsMinutes += evtRgv['span']['minutes'] % 60
                        if 'seconds' in evtRgv['span']:
                            lastsMinutes += evtRgv['span']['seconds'] // 60
                        lastsHours += lastsMinutes // 60
                        lastsMinutes %= 60
                        lastsDays += lastsHours // 24
                        lastsHours %= 24
                        self.novel.sections[scId].lastsDays = str(lastsDays)
                        self.novel.sections[scId].lastsHours = str(lastsHours)
                        self.novel.sections[scId].lastsMinutes = str(lastsMinutes)
                    break

            if not timestamp in scIdsByDate:
                scIdsByDate[timestamp] = []
            scIdsByDate[timestamp].append(scId)

            self.novel.sections[scId].scType = 1
            scCharacters = []
            scLocations = []
            scItems = []
            for evtRel in event['relationships']:

                if evtRel['role'] == self._roleArcGuid:
                    if evtRel['entity'] == self._entityNarrativeGuid:
                        self.novel.sections[scId].scType = 0
                        if timestamp > self._timestampMax:
                            self._timestampMax = timestamp

                elif evtRel['role'] == self._roleCharacterGuid:
                    crId = crIdsByGuid[evtRel['entity']]
                    scCharacters.append(crId)

                elif evtRel['role'] == self._roleLocationGuid:
                    lcId = lcIdsByGuid[evtRel['entity']]
                    scLocations.append(lcId)

                elif evtRel['role'] == self._roleItemGuid:
                    itId = itIdsByGuid[evtRel['entity']]
                    scItems.append(itId)

                elif evtRel['role'] == self._rolePlotlineGuid:
                    acId = acIdsByGuid[evtRel['entity']]
                    self.novel.sections[scId].scPlotLines.append(acId)

                    acSections = self.novel.plotLines[acId].sections
                    if acSections is None:
                        acSections = []
                    acSections.append(scId)
                    self.novel.plotLines[acId].sections = acSections

            if scCharacters:
                self.novel.sections[scId].characters = scCharacters
            if scLocations:
                self.novel.sections[scId].locations = scLocations
            if scItems:
                self.novel.sections[scId].items = scItems
        return narrativeEvents, scIdsByDate

    def _set_reference_date(self, novel):
        self.referenceDate = datetime.today()
        if novel.referenceDate:
            defaultDateTime = f'{novel.referenceDate} 00:00:00'
            try:
                self.referenceDate = datetime.fromisoformat(defaultDateTime)
            except ValueError:
                pass

    def _w_check_source_arcs(self, source, relatedArcs):
        srcArcTitles = []
        for acId in source.plotLines:
            if not acId in relatedArcs:
                continue

            if source.plotLines[acId].title in srcArcTitles:
                raise Error(_('Ambiguous novelibre plot line "{}".').format(source.plotLines[acId].title))

            srcArcTitles.append(source.plotLines[acId].title)

    def _w_check_source_characters(self, source, relatedCharacters):
        srcChrNames = []
        for crId in source.characters:
            if not crId in relatedCharacters:
                continue

            if source.characters[crId].title in srcChrNames:
                raise Error(_('Ambiguous novelibre character "{}".').format(source.characters[crId].title))

            srcChrNames.append(source.characters[crId].title)

    def _w_check_source_locations(self, source, relatedLocations):
        srcLocTitles = []
        for lcId in source.locations:
            if not lcId in relatedLocations:
                continue

            if source.locations[lcId].title in srcLocTitles:
                raise Error(_('Ambiguous novelibre location "{}".').format(source.locations[lcId].title))

            srcLocTitles.append(source.locations[lcId].title)

    def _w_check_source_items(self, source, relatedItems):
        srcItmTitles = []
        for itId in source.items:
            if not itId in relatedItems:
                continue

            if source.items[itId].title in srcItmTitles:
                raise Error(_('Ambiguous novelibre item "{}".').format(source.items[itId].title))

            srcItmTitles.append(source.items[itId].title)

    def _w_check_source_sections(self, source):
        srcScnTitles = []
        for chId in source.chapters:
            if source.chapters[chId].isTrash:
                continue

            for scId in source.tree.get_children(chId):
                if source.sections[scId].title in srcScnTitles:
                    raise Error(_('Ambiguous novelibre section title "{}".').format(source.sections[scId].title))

                srcScnTitles.append(source.sections[scId].title)
        return srcScnTitles

    def _w_check_target_arcs(self):
        acIdsByTitle = {}
        for acId in self.novel.plotLines:
            if self.novel.plotLines[acId].title in acIdsByTitle:
                raise Error(_('Ambiguous Aeon arc "{}".').format(self.novel.plotLines[acId].title))

            acIdsByTitle[self.novel.plotLines[acId].title] = acId
        return acIdsByTitle

    def _w_check_target_characters(self):
        crIdsByTitle = {}
        for crId in self.novel.characters:
            if self.novel.characters[crId].title in crIdsByTitle:
                raise Error(_('Ambiguous Aeon character "{}".').format(self.novel.characters[crId].title))

            crIdsByTitle[self.novel.characters[crId].title] = crId
        return crIdsByTitle

    def _w_check_target_items(self):
        itIdsByTitle = {}
        for itId in self.novel.items:
            if self.novel.items[itId].title in itIdsByTitle:
                raise Error(_('Ambiguous Aeon item "{}".').format(self.novel.items[itId].title))

            itIdsByTitle[self.novel.items[itId].title] = itId
        return itIdsByTitle

    def _w_check_target_locations(self):
        lcIdsByTitle = {}
        for lcId in self.novel.locations:
            if self.novel.locations[lcId].title in lcIdsByTitle:
                raise Error(_('Ambiguous Aeon location "{}".').format(self.novel.locations[lcId].title))

            lcIdsByTitle[self.novel.locations[lcId].title] = lcId
        return lcIdsByTitle

    def _w_check_target_sections(self):
        scIdsByTitle = {}
        for scId in self.novel.sections:
            if self.novel.sections[scId].title in scIdsByTitle:

                raise Error(_('Ambiguous Aeon event title "{}".').format(self.novel.sections[scId].title))
            scIdsByTitle[self.novel.sections[scId].title] = scId
        return scIdsByTitle

    def _w_collect_trashed_sections(self, srcScnTitles):
        for scId in self.novel.sections:
            if self.novel.sections[scId].title in srcScnTitles:
                continue

            if self.novel.sections[scId].scType == 1:
                continue

            self._trashEvents.append(scId)

    def _w_create_json_narrative_arc_if_missing(self):
        if self._entityNarrativeGuid is not None:
            return

        self._entityNarrativeGuid = self._guidGen.get_guid('entityNarrativeGuid')
        self._jsonData['entities'].append({
                'entityType':self._typeArcGuid,
                'guid':self._entityNarrativeGuid,
                'icon':'book',
                'name':self._entityNarrative,
                'notes':'',
                'sortOrder':self._arcCount,
                'swatchColor':'orange'})
        self._arcCount += 1

    def _w_create_json_property_desc_if_missing(self):
        if self._propertyDescGuid is not None:
            return

        n = len(self._jsonData['template']['properties'])
        self._propertyDescGuid = self._guidGen.get_guid('_propertyDescGuid')
        self._jsonData['template']['properties'].append({'calcMode':'default',
                'calculate':False,
                'fadeEvents':False,
                'guid':self._propertyDescGuid,
                'icon':'tag',
                'isMandatory':False,
                'name':self._propertyDesc,
                'sortOrder':n,
                'type':'multitext'})

    def _w_create_json_property_moonphase_if_missing(self):
        if self._propertyMoonphaseGuid is not None:
            return

        if not self._addMoonphase:
            return

        n = len(self._jsonData['template']['properties'])
        self._propertyMoonphaseGuid = self._guidGen.get_guid('_propertyMoonphaseGuid')
        self._jsonData['template']['properties'].append({'calcMode':'default',
                'calculate':False,
                'fadeEvents':False,
                'guid':self._propertyMoonphaseGuid,
                'icon':'flag',
                'isMandatory':False,
                'name':self._propertyMoonphase,
                'sortOrder':n,
                'type':'text'})

    def _w_create_json_property_notes_if_missing(self):
        if self._propertyNotesGuid is not None:
            return

        for tplPrp in self._jsonData['template']['properties']:
            tplPrp['sortOrder'] += 1

        self._propertyNotesGuid = self._guidGen.get_guid('_propertyNotesGuid')
        self._jsonData['template']['properties'].insert(0, {'calcMode':'default',
                'calculate':False,
                'fadeEvents':False,
                'guid':self._propertyNotesGuid,
                'icon':'tag',
                'isMandatory':False,
                'name':self._propertyNotes,
                'sortOrder':0,
                'type':'multitext'})

    def _w_create_json_role_arc_if_missing(self):
        if self._roleArcGuid is not None:
            return

        for entityType in self._jsonData['template']['types']:
            if entityType['name'] == self._typeArc:
                self._roleArcGuid = self._guidGen.get_guid('_roleArcGuid')
                entityType['roles'].append(
                    {
                        'allowsMultipleForEntity':True,
                        'allowsMultipleForEvent':True,
                        'allowsPercentAllocated':False,
                        'guid':self._roleArcGuid,
                        'icon':'circle text',
                        'mandatoryForEntity':False,
                        'mandatoryForEvent':False,
                        'name':self._roleArc,
                        'sortOrder':0})
                return

    def _w_create_json_role_character_if_missing(self):
        if self._roleCharacterGuid is not None:
            return

        for entityType in self._jsonData['template']['types']:
            if entityType['name'] == self._typeCharacter:
                self._roleCharacterGuid = self._guidGen.get_guid('_roleCharacterGuid')
                entityType['roles'].append(
                    {
                        'allowsMultipleForEntity':True,
                        'allowsMultipleForEvent':True,
                        'allowsPercentAllocated':False,
                        'guid':self._roleCharacterGuid,
                        'icon':'circle text',
                        'mandatoryForEntity':False,
                        'mandatoryForEvent':False,
                        'name':self._roleCharacter,
                        'sortOrder':0})
                return

    def _w_create_json_role_item_if_missing(self):
        if self._roleItemGuid is not None:
            return

        for entityType in self._jsonData['template']['types']:
            if entityType['name'] == self._typeItem:
                self._roleItemGuid = self._guidGen.get_guid('_roleItemGuid')
                entityType['roles'].append(
                    {
                        'allowsMultipleForEntity':True,
                        'allowsMultipleForEvent':True,
                        'allowsPercentAllocated':False,
                        'guid':self._roleItemGuid,
                        'icon':'circle text',
                        'mandatoryForEntity':False,
                        'mandatoryForEvent':False,
                        'name':self._roleItem,
                        'sortOrder':0})
                return

    def _w_create_json_role_location_if_missing(self):
        if self._roleLocationGuid is not None:
            return

        for entityType in self._jsonData['template']['types']:
            if entityType['name'] == self._typeLocation:
                self._roleLocationGuid = self._guidGen.get_guid('_roleLocationGuid')
                entityType['roles'].append(
                    {
                        'allowsMultipleForEntity':True,
                        'allowsMultipleForEvent':True,
                        'allowsPercentAllocated':False,
                        'guid':self._roleLocationGuid,
                        'icon':'circle text',
                        'mandatoryForEntity':False,
                        'mandatoryForEvent':False,
                        'name':self._roleLocation,
                        'sortOrder':0})
                return

    def _w_create_json_role_plotline_if_missing(self):
        if self._rolePlotlineGuid is not None:
            return

        for entityType in self._jsonData['template']['types']:
            if entityType['name'] == self._typeArc:
                self._rolePlotlineGuid = self._guidGen.get_guid('_roleStorylineGuid')
                entityType['roles'].append(
                    {
                        'allowsMultipleForEntity':True,
                        'allowsMultipleForEvent':True,
                        'allowsPercentAllocated':False,
                        'guid':self._rolePlotlineGuid,
                        'icon':'circle filled text',
                        'mandatoryForEntity':False,
                        'mandatoryForEvent':False,
                        'name':self._rolePlotline,
                        'sortOrder':0})
                return

    def _w_create_json_type_arc_if_missing(self):
        if self._typeArcGuid is not None:
            return

        self._typeArcGuid = self._guidGen.get_guid('typeArcGuid')
        typeCount = len(self._jsonData['template']['types'])
        self._jsonData['template']['types'].append({
                'color':'iconYellow',
                'guid':self._typeArcGuid,
                'icon':'book',
                'name':self._typeArc,
                'persistent':True,
                'roles':[],
                'sortOrder':typeCount})

    def _w_create_json_type_character_if_missing(self):
        if self._typeCharacterGuid is not None:
            return

        self._typeCharacterGuid = self._guidGen.get_guid('_typeCharacterGuid')
        self._roleCharacterGuid = self._guidGen.get_guid('_roleCharacterGuid')
        typeCount = len(self._jsonData['template']['types'])
        self._jsonData['template']['types'].append({
                'color':'iconRed',
                'guid':self._typeCharacterGuid,
                'icon':'person',
                'name':self._typeCharacter,
                'persistent':False,
                'roles':[],
                'sortOrder':typeCount})

    def _w_create_json_type_item_if_missing(self):
        if self._typeItemGuid is not None:
            return

        self._typeItemGuid = self._guidGen.get_guid('_typeItemGuid')
        self._roleItemGuid = self._guidGen.get_guid('_roleItemGuid')
        typeCount = len(self._jsonData['template']['types'])
        self._jsonData['template']['types'].append({
                'color':'iconPurple',
                'guid':self._typeItemGuid,
                'icon':'cube',
                'name':self._typeItem,
                'persistent':True,
                'roles':[],
                'sortOrder':typeCount})

    def _w_create_json_type_location_if_missing(self):
        if self._typeLocationGuid is not None:
            return

        self._typeLocationGuid = self._guidGen.get_guid('_typeLocationGuid')
        self._roleLocationGuid = self._guidGen.get_guid('_roleLocationGuid')
        typeCount = len(self._jsonData['template']['types'])
        self._jsonData['template']['types'].append({
                'color':'iconOrange',
                'guid':self._typeLocationGuid,
                'icon':'map',
                'name':self._typeLocation,
                'persistent':True,
                'roles':[],
                'sortOrder':typeCount})

    def _w_delete_trashed_events(self, scIdsByTitle):
        jEvents = []
        for jEvent in self._jsonData['events']:
            jTitle = jEvent['title']
            if jTitle in scIdsByTitle:
                scId = scIdsByTitle[jTitle]
                if not scId in self._trashEvents:
                    jEvents.append(jEvent)
            else:
                jEvents.append(jEvent)
        self._jsonData['events'] = jEvents

    def _w_get_json_character_date(self, isoDate):
        charaDate = datetime.fromisoformat(isoDate)
        timestamp = int((charaDate - datetime.min).total_seconds())
        return {
            "precision": "day",
            "rangePropertyGuid": self._tplDateGuid,
            "timestamp": timestamp
            }

    def _w_get_display_id(self):
        self._displayIdMax += 1
        return str(int(self._displayIdMax))

    def _w_get_new_json_event(self, section):
        event = {
            'attachments': [],
            'color': '',
            'displayId': self._w_get_display_id(),
            'guid': self._guidGen.get_guid(f'section{section.title}'),
            'links': [],
            'locked': False,
            'priority': 500,
            'rangeValues': [{
                'minimumZoom':-1,
                'position': {
                    'precision': 'minute',
                    'timestamp': self.DATE_LIMIT
                    },
                'rangeProperty': self._tplDateGuid,
                'span': {},
                }],
            'relationships': [],
            'tags': [],
            'title': section.title,
            'values': [{
                'property': self._propertyNotesGuid,
                'value': ''
                },
                {
                'property': self._propertyDescGuid,
                'value': ''
                }],
            }
        if section.scType == 0:
            event['color'] = self._colors[self._sectionColor]
        else:
            event['color'] = self._colors[self._eventColor]
        return event

    def _w_get_related_elements(self, source):
        relatedCharacters = []
        relatedLocations = []
        relatedItems = []
        relatedArcs = []
        for chId in source.chapters:
            if source.chapters[chId].isTrash:
                continue

            for scId in source.tree.get_children(chId):
                if source.sections[scId].characters:
                    relatedCharacters = list(set(relatedCharacters + source.sections[scId].characters))
                if source.sections[scId].locations:
                    relatedLocations = list(set(relatedLocations + source.sections[scId].locations))
                if source.sections[scId].items:
                    relatedItems = list(set(relatedItems + source.sections[scId].items))
                if source.sections[scId].scPlotLines:
                    relatedArcs = list(set(relatedArcs + source.sections[scId].scPlotLines))
        return relatedCharacters, relatedLocations, relatedItems, relatedArcs

    def _w_get_span(self, section):
        span = {}
        if section.lastsDays:
            lastsDays = int(section.lastsDays)
            if lastsDays:
                span['days'] = lastsDays
        if section.lastsHours:
            lastsHours = int(section.lastsHours)
            if lastsHours:
                span['hours'] = lastsHours
        if section.lastsMinutes:
            lastsMinutes = int(section.lastsMinutes)
            if lastsMinutes:
                span['minutes'] = lastsMinutes
        return span

    def _w_get_timestamp(self, section):
        self._timestampMax += 1
        timestamp = int(self._timestampMax)
        try:
            if section.date:
                isoDt = section.date
                if section.time:
                    isoDt = (f'{isoDt} {section.time}')
            timestamp = int((datetime.fromisoformat(isoDt) - datetime.min).total_seconds())
        except:
            pass
        return timestamp

    def _w_update_arcs_from_source(self, source, acIdsByTitle, linkedArcs):
        arcCount = len(self.novel.plotLines)
        acIdsBySrcId = {}
        for srcAcId in source.plotLines:
            if source.plotLines[srcAcId].title in acIdsByTitle:
                acIdsBySrcId[srcAcId] = acIdsByTitle[source.plotLines[srcAcId].title]
            elif srcAcId in linkedArcs:

                acId = new_id(self.novel.plotLines, prefix=PLOT_LINE_PREFIX)
                acIdsBySrcId[srcAcId] = acId
                self.novel.plotLines[acId] = source.plotLines[srcAcId]
                arcName = self.novel.plotLines[acId].title
                newGuid = self._guidGen.get_guid(f'{acId}{arcName}')
                self._arcGuidsById[acId] = newGuid
                self._jsonData['entities'].append(
                    {
                        'entityType':self._typeArcGuid,
                        'guid':newGuid,
                        'icon':'book',
                        'name':arcName,
                        'notes':'',
                        'sortOrder':self._arcCount,
                        'swatchColor':'orange'})
                arcCount += 1
        return acIdsBySrcId

    def _w_update_characters_from_source(self, source, crIdsByTitle, linkedCharacters):
        chrCount = len(self.novel.characters)
        crIdsBySrcId = {}
        srcIdsbyCrId = {}
        for srcCrId in source.characters:
            if source.characters[srcCrId].title in crIdsByTitle:
                crId = crIdsByTitle[source.characters[srcCrId].title]
                crIdsBySrcId[srcCrId] = crId
                srcIdsbyCrId[crId] = srcCrId
            elif srcCrId in linkedCharacters:

                crId = new_id(self.novel.characters, prefix=CHARACTER_PREFIX)
                crIdsBySrcId[srcCrId] = crId
                srcIdsbyCrId[crId] = srcCrId
                self.novel.characters[crId] = source.characters[srcCrId]
                newGuid = self._guidGen.get_guid(f'{crId}{self.novel.characters[crId].title}')
                self._characterGuidsById[crId] = newGuid
                jsonCharacter = {}
                birthDate = self.novel.characters[crId].birthDate
                if birthDate:
                    jsonCharacter['createRangePosition'] = self._w_get_json_character_date(birthDate)
                deathDate = self.novel.characters[crId].deathDate
                if deathDate:
                    jsonCharacter['destroyRangePosition'] = self._w_get_json_character_date(deathDate)
                jsonCharacter['entityType'] = self._typeCharacterGuid
                jsonCharacter['guid'] = newGuid
                jsonCharacter['icon'] = 'person'
                jsonCharacter['name'] = self.novel.characters[crId].title
                jsonCharacter['notes'] = ''
                jsonCharacter['sortOrder'] = chrCount
                jsonCharacter['swatchColor'] = 'darkPink'
                self._jsonData['entities'].append(jsonCharacter)
                chrCount += 1

        for entity in self._jsonData['entities']:
            if not entity['entityType'] == self._typeCharacterGuid:
                continue

            if not entity['name'] in crIdsByTitle:
                continue

            crId = crIdsByTitle[entity['name']]
            srcCrId = srcIdsbyCrId[crId]
            birthDate = source.characters[srcCrId].birthDate
            if birthDate:
                entity['createRangePosition'] = self._w_get_json_character_date(birthDate)
            elif 'createRangePosition' in entity:
                    del entity['createRangePosition']
            deathDate = source.characters[srcCrId].deathDate
            if deathDate:
                entity['destroyRangePosition'] = self._w_get_json_character_date(deathDate)
            elif 'destroyRangePosition' in entity:
                    del entity['destroyRangePosition']

        return crIdsBySrcId

    def _w_update_json_events_from_sections(self, scIdsByTitle):
        for jEvent in self._jsonData['events']:
            if not jEvent['title'] in scIdsByTitle:
                continue

            scId = scIdsByTitle[jEvent['title']]

            if jEvent['rangeValues'][0]['position']['timestamp'] >= self.DATE_LIMIT:
                jEvent['rangeValues'][0]['span'] = self._w_get_span(self.novel.sections[scId])
                jEvent['rangeValues'][0]['position']['timestamp'] = self._w_get_timestamp(self.novel.sections[scId])

            if self._propertyMoonphaseGuid is not None:
                eventMoonphase = self._nvSvc.get_moon_phase_str(self.novel.sections[scId].date)
            else:
                eventMoonphase = ''

            hasMoonphase = False
            for evtVal in jEvent['values']:

                if evtVal['property'] == self._propertyDescGuid:
                    if self.novel.sections[scId].desc:
                        evtVal['value'] = self.novel.sections[scId].desc

                elif evtVal['property'] == self._propertyNotesGuid:
                    if self.novel.sections[scId].notes:
                        evtVal['value'] = self.novel.sections[scId].notes

                elif evtVal['property'] == self._propertyMoonphaseGuid:
                        evtVal['value'] = eventMoonphase
                        hasMoonphase = True

            if not hasMoonphase and self._propertyMoonphaseGuid is not None:
                jEvent['values'].append({'property': self._propertyMoonphaseGuid, 'value': eventMoonphase})

            if self.novel.sections[scId].tags:
                jEvent['tags'] = self.novel.sections[scId].tags


            newRel = []
            for evtRel in jEvent['relationships']:
                if evtRel['role'] == self._roleCharacterGuid:
                    continue

                elif evtRel['role'] == self._roleLocationGuid:
                    continue

                elif evtRel['role'] == self._roleItemGuid:
                    continue

                elif evtRel['role'] == self._roleArcGuid:
                    continue

                else:
                    newRel.append(evtRel)

            if self.novel.sections[scId].characters:
                for crId in self.novel.sections[scId].characters:
                    newRel.append(
                        {
                        'entity': self._characterGuidsById[crId],
                        'percentAllocated': 1,
                        'role': self._roleCharacterGuid,
                        })

            if self.novel.sections[scId].locations:
                for lcId in self.novel.sections[scId].locations:
                    newRel.append(
                        {
                        'entity': self._locationGuidsById[lcId],
                        'percentAllocated': 1,
                        'role': self._roleLocationGuid,
                        })

            if self.novel.sections[scId].items:
                for itId in self.novel.sections[scId].items:
                    newRel.append(
                        {
                        'entity': self._itemGuidsById[itId],
                        'percentAllocated': 1,
                        'role': self._roleItemGuid,
                        })

            if self.novel.sections[scId].scType == 0:
                newRel.append(
                    {
                    'entity': self._entityNarrativeGuid,
                    'percentAllocated': 1,
                    'role': self._roleArcGuid,
                    })

                if self.novel.sections[scId].scPlotLines:
                    for acId in self.novel.sections[scId].scPlotLines:
                        newRel.append(
                            {
                            'entity': self._arcGuidsById[acId],
                            'percentAllocated': 1,
                            'role': self._rolePlotlineGuid,
                            })

            jEvent['relationships'] = newRel

    def _w_update_items_from_source(self, source, itIdsByTitle, linkedItems):
        itmCount = len(self.novel.items)
        itIdsBySrcId = {}
        for srcItId in source.items:
            if source.items[srcItId].title in itIdsByTitle:
                itIdsBySrcId[srcItId] = itIdsByTitle[source.items[srcItId].title]
            elif srcItId in linkedItems:

                itId = new_id(self.novel.items, prefix=ITEM_PREFIX)
                itIdsBySrcId[srcItId] = itId
                self.novel.items[itId] = source.items[srcItId]
                newGuid = self._guidGen.get_guid(f'{itId}{self.novel.items[itId].title}')
                self._itemGuidsById[itId] = newGuid
                self._jsonData['entities'].append({
                        'entityType':self._typeItemGuid,
                        'guid':newGuid,
                        'icon':'cube',
                        'name':self.novel.items[itId].title,
                        'notes':'',
                        'sortOrder':itmCount,
                        'swatchColor':'denim'})
                itmCount += 1
        return itIdsBySrcId

    def _w_update_locations_from_source(self, source, lcIdsByTitle, linkedLocations):
        locCount = len(self.novel.locations)
        lcIdsBySrcId = {}
        for srcLcId in source.locations:
            if source.locations[srcLcId].title in lcIdsByTitle:
                lcIdsBySrcId[srcLcId] = lcIdsByTitle[source.locations[srcLcId].title]
            elif srcLcId in linkedLocations:

                lcId = new_id(self.novel.locations, prefix=LOCATION_PREFIX)
                lcIdsBySrcId[srcLcId] = lcId
                self.novel.locations[lcId] = source.locations[srcLcId]
                newGuid = self._guidGen.get_guid(f'{lcId}{self.novel.locations[lcId].title}')
                self._locationGuidsById[lcId] = newGuid
                self._jsonData['entities'].append({
                        'entityType':self._typeLocationGuid,
                        'guid':newGuid,
                        'icon':'map',
                        'name':self.novel.locations[lcId].title,
                        'notes':'',
                        'sortOrder':locCount,
                        'swatchColor':'orange'})
                locCount += 1

        return lcIdsBySrcId

    def _w_update_sections_from_source(self, source, scIdsByTitle, crIdsBySrcId, lcIdsBySrcId, itIdsBySrcId, acIdsBySrcId):
        for srcId in source.sections:
            if source.sections[srcId].scType != 0:
                if source.sections[srcId].title in scIdsByTitle:
                    scId = scIdsByTitle[source.sections[srcId].title]
                    self.novel.sections[scId].scType = 1
                continue

            if source.sections[srcId].title in scIdsByTitle:
                scId = scIdsByTitle[source.sections[srcId].title]
            else:
                scId = new_id(self.novel.sections, prefix=SECTION_PREFIX)
                self.novel.sections[scId] = self._nvSvc.new_section(
                    title=source.sections[srcId].title,
                    scType=source.sections[srcId].scType,
                    scene=source.sections[srcId].scene
                    )
                scIdsByTitle[self.novel.sections[scId].title] = scId
                newEvent = self._w_get_new_json_event(self.novel.sections[scId])
                self._jsonData['events'].append(newEvent)
            self.novel.sections[scId].status = source.sections[srcId].status

            if source.sections[srcId].scType is not None:
                self.novel.sections[scId].scType = source.sections[srcId].scType

            if source.sections[srcId].tags is not None:
                self.novel.sections[scId].tags = source.sections[srcId].tags

            if source.sections[srcId].desc is not None:
                self.novel.sections[scId].desc = source.sections[srcId].desc

            if source.sections[srcId].characters is not None:
                scCharacters = []
                for crId in source.sections[srcId].characters:
                    if crId in crIdsBySrcId:
                        scCharacters.append(crIdsBySrcId[crId])
                self.novel.sections[scId].characters = scCharacters

            if source.sections[srcId].locations is not None:
                scLocations = []
                for lcId in source.sections[srcId].locations:
                    if lcId in lcIdsBySrcId:
                        scLocations.append(lcIdsBySrcId[lcId])
                self.novel.sections[scId].locations = scLocations

            if source.sections[srcId].items is not None:
                scItems = []
                for itId in source.sections[srcId].items:
                    if itId in itIdsBySrcId:
                        scItems.append(itIdsBySrcId[itId])
                self.novel.sections[scId].items = scItems

            if source.sections[srcId].scPlotLines is not None:
                scArcs = []
                for acId in source.sections[srcId].scPlotLines:
                    if acId in acIdsBySrcId:
                        scArcs.append(acIdsBySrcId[acId])
                self.novel.sections[scId].scPlotLines = scArcs

            if source.sections[srcId].time is not None:
                self.novel.sections[scId].time = source.sections[srcId].time

            if source.sections[srcId].day is not None:
                dayInt = int(source.sections[srcId].day)
                sectionDelta = timedelta(days=dayInt)
                self.novel.sections[scId].date = (self.referenceDate + sectionDelta).isoformat().split('T')[0]
            elif source.sections[srcId].date is None:
                self.novel.sections[scId].date = self.referenceDate.isoformat().split('T')[0]
            else:
                self.novel.sections[scId].date = source.sections[srcId].date

            if source.sections[srcId].lastsMinutes is None:
                self.novel.sections[scId].lastsMinutes = '0'
            else:
                self.novel.sections[scId].lastsMinutes = source.sections[srcId].lastsMinutes
            if source.sections[srcId].lastsHours is None:
                self.novel.sections[scId].lastsHours = '0'
            else:
                self.novel.sections[scId].lastsHours = source.sections[srcId].lastsHours
            if source.sections[srcId].lastsDays is None:
                self.novel.sections[scId].lastsDays = '0'
            else:
                self.novel.sections[scId].lastsDays = source.sections[srcId].lastsDays

from abc import ABC, abstractmethod



class SubController:

    def initialize_controller(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass



class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller):
        self.initialize_controller(model, view, controller)

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass



def open_document(document):
    try:
        os.startfile(norm_path(document))
    except:
        try:
            os.system('xdg-open "%s"' % norm_path(document))
        except:
            try:
                os.system('open "%s"' % norm_path(document))
            except:
                pass
import tkinter as tk


class Plugin(PluginBase):
    VERSION = '5.0.1'
    API_VERSION = '5.0'
    DESCRIPTION = 'Synchronize with Aeon Timeline 2'
    URL = 'https://github.com/peter88213/nv_aeon2'
    _HELP_URL = f'{_("https://peter88213.github.io/nvhelp-en")}/nv_aeon2/'

    FEATURE = 'Aeon Timeline 2'
    INI_FILENAME = 'nv_aeon2.ini'
    INI_FILEPATH = '.novx/config'
    SETTINGS = dict(
        narrative_arc='Narrative',
        property_description='Description',
        property_notes='Notes',
        property_moonphase='Moon phase',
        type_arc='Arc',
        type_character='Character',
        type_location='Location',
        type_item='Item',
        role_arc='Arc',
        role_plotline='Storyline',
        role_character='Participant',
        role_item='Item',
        role_location='Location',
        color_section='Red',
        color_event='Yellow',

    )
    OPTIONS = dict(
        add_moonphase=False,
        lock_on_export=False,
    )

    def disable_menu(self):
        """Disable menu entries when no project is open.
        
        Overrides the superclass method.
        """
        self._ui.toolsMenu.entryconfig(self.FEATURE, state='disabled')
        self._timelineButton.config(state='disabled')

    def enable_menu(self):
        """Enable menu entries when a project is open.
                
        Overrides the superclass method.
        """
        self._ui.toolsMenu.entryconfig(self.FEATURE, state='normal')
        self._timelineButton.config(state='normal')

    def install(self, model, view, controller):
        """Add a submenu to the main menu.
        
        Positional arguments:
            model -- reference to the main model instance of the application.
            view -- reference to the main view instance of the application.
            controller -- reference to the main controller instance of the application.

        Optional arguments:
            prefs -- deprecated. Please use controller.get_preferences() instead.
        
        Extends the superclass method.
        """
        super().install(model, view, controller)

        self._pluginMenu = tk.Menu(self._ui.toolsMenu, tearoff=0)
        self._ui.toolsMenu.add_cascade(label=self.FEATURE, menu=self._pluginMenu)
        self._ui.toolsMenu.entryconfig(self.FEATURE, state='disabled')
        self._pluginMenu.add_command(label=_('Information'), command=self._info)
        self._pluginMenu.add_separator()
        self._pluginMenu.add_command(label=_('Update the timeline'), command=self._export_from_novx)
        self._pluginMenu.add_command(label=_('Update the project'), command=self._import_to_novx)
        self._pluginMenu.add_separator()
        self._pluginMenu.add_command(label=_('Add or update moon phase data'), command=self._add_moonphase)
        self._pluginMenu.add_separator()
        self._pluginMenu.add_command(label=_('Open Aeon Timeline 2'), command=self._launch_application)

        self._ui.newMenu.add_command(label=_('Create from Aeon Timeline 2...'), command=self._create_novx)

        self._ui.helpMenu.add_command(label=_('Aeon 2 plugin Online help'), command=lambda: webbrowser.open(self._HELP_URL))

        self._configure_toolbar()

    def lock(self):
        """Inhibit changes on the model.
        
        Overrides the superclass method.
        """
        self._pluginMenu.entryconfig(_('Update the project'), state='disabled')

    def unlock(self):
        """Enable changes on the model.
        
        Overrides the superclass method.
        """
        self._pluginMenu.entryconfig(_('Update the project'), state='normal')

    def _add_moonphase(self):
        """Add/update moon phase data.
        
        Add the moon phase to the event properties.
        If the moon phase event property already exists, just update.
        """
        if not self._mdl.prjFile:
            return

        timelinePath = f'{os.path.splitext(self._mdl.prjFile.filePath)[0]}{JsonTimeline2.EXTENSION}'
        if not os.path.isfile(timelinePath):
            return

        sourceDir = os.path.dirname(timelinePath)
        if not sourceDir:
            sourceDir = '.'
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            pluginCnfDir = f'{homeDir}/{self.INI_FILEPATH}'
        except:
            pluginCnfDir = '.'
        iniFiles = [f'{pluginCnfDir}/{self.INI_FILENAME}', f'{sourceDir}/{self.INI_FILENAME}']
        configuration = self._mdl.nvService.new_configuration(
            settings=self.SETTINGS,
            options=self.OPTIONS
            )
        for iniFile in iniFiles:
            configuration.read(iniFile)
        kwargs = {}
        kwargs.update(configuration.settings)
        kwargs.update(configuration.options)
        kwargs['add_moonphase'] = True
        kwargs['nv_service'] = self._mdl.nvService
        timeline = JsonTimeline2(timelinePath, **kwargs)
        timeline.novel = self._mdl.nvService.new_novel()
        try:
            timeline.read()
            timeline.write(timeline.novel)
        except Error as ex:
            message = f'!{str(ex)}'
        else:
            message = f'{_("File written")}: "{norm_path(timeline.filePath)}".'
        self._ui.set_status(message)

    def _configure_toolbar(self):

        prefs = self._ctrl.get_preferences()
        if prefs.get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
        except:
            iconPath = None
        try:
            aeon2Icon = tk.PhotoImage(file=f'{iconPath}/aeon2.png')
        except:
            aeon2Icon = None

        tk.Frame(self._ui.toolbar.buttonBar, bg='light gray', width=1).pack(side='left', fill='y', padx=4)

        self._timelineButton = ttk.Button(
            self._ui.toolbar.buttonBar,
            text=_('Open Aeon Timeline 2'),
            image=aeon2Icon,
            command=self._launch_application
            )
        self._timelineButton.pack(side='left')
        self._timelineButton.image = aeon2Icon

        if not prefs['enable_hovertips']:
            return

        try:
            from idlelib.tooltip import Hovertip
        except ModuleNotFoundError:
            return

        Hovertip(self._timelineButton, self._timelineButton['text'])

    def _create_novx(self):
        timelinePath = filedialog.askopenfilename(
            filetypes=[(JsonTimeline2.DESCRIPTION, JsonTimeline2.EXTENSION)],
            defaultextension=JsonTimeline2.EXTENSION,
            )
        if not timelinePath:
            return

        self._ctrl.close_project()
        root, __ = os.path.splitext(timelinePath)
        novxPath = f'{root}{self._mdl.nvService.get_novx_file_extension()}'
        kwargs = self._get_configuration(timelinePath)
        kwargs['nv_service'] = self._mdl.nvService
        source = JsonTimeline2(timelinePath, **kwargs)
        target = self._mdl.nvService.new_novx_file(novxPath)

        if os.path.isfile(target.filePath):
            self._ui.set_status(f'!{_("File already exists")}: "{norm_path(target.filePath)}".')
            return

        message = ''
        try:
            source.novel = self._mdl.nvService.new_novel()
            source.read()
            target.novel = source.novel
            target.write()
        except Error as ex:
            message = f'!{str(ex)}'
        else:
            message = f'{_("File written")}: "{norm_path(target.filePath)}".'
            self._ctrl.open_project(filePath=target.filePath, doNotSave=True)
        finally:
            self._ui.set_status(message)

    def _edit_settings(self):
        return

    def _export_from_novx(self):
        """Update the timeline file from the novx file.
        
        Note:
        The model's novel is not used as the conversion source here.
        It is considered safer to use a copy of the novel read from the file.
        """
        if not self._mdl.prjFile:
            return

        self._ui.propertiesView.apply_changes()
        self._ui.restore_status()
        if not self._mdl.prjFile.filePath:
            if not self._ctrl.save_project():
                return

        timelinePath = f'{os.path.splitext(self._mdl.prjFile.filePath)[0]}{JsonTimeline2.EXTENSION}'
        if not os.path.isfile(timelinePath):
            self._ui.set_status(_('!No {} file available for this project.').format(self.FEATURE))
            return

        if self._mdl.isModified:
            if not self._ui.ask_yes_no(_('Save the project and update the timeline?')):
                return

            self._ctrl.save_project()
        elif not self._ui.ask_yes_no(_('Update the timeline?')):
            return

        kwargs = self._get_configuration(timelinePath)
        kwargs['nv_service'] = self._mdl.nvService
        source = self._mdl.nvService.new_novx_file(self._mdl.prjFile.filePath, **kwargs)
        source.novel = self._mdl.nvService.new_novel()
        target = JsonTimeline2(timelinePath, **kwargs)
        target.novel = self._mdl.nvService.new_novel()
        try:
            source.read()
            target.read()
            target.write(source.novel)
            message = f'{_("File written")}: "{norm_path(target.filePath)}".'
        except Error as ex:
            message = f'!{str(ex)}'
        self._ui.set_status(message)

    def _get_configuration(self, sourcePath):
        """ Read persistent configuration data for Aeon 2 conversion.
        
        First, look for a global configuration file in the aeon2nv installation directory,
        then look for a local configuration file in the project directory.
        """
        sourceDir = os.path.dirname(sourcePath)
        if not sourceDir:
            sourceDir = '.'
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            pluginCnfDir = f'{homeDir}/{self.INI_FILEPATH}'
        except:
            pluginCnfDir = '.'
        iniFiles = [f'{pluginCnfDir}/{self.INI_FILENAME}', f'{sourceDir}/{self.INI_FILENAME}']
        configuration = self._mdl.nvService.new_configuration(
            settings=self.SETTINGS,
            options=self.OPTIONS
            )
        for iniFile in iniFiles:
            configuration.read(iniFile)
        kwargs = {}
        kwargs.update(configuration.settings)
        kwargs.update(configuration.options)
        return kwargs

    def _import_to_novx(self):
        """Update the current project file from the timeline file.
        
        Note:
        The NvWorkFile object of the open project cannot be used as target object.
        This is because the JsonTimeline2 source object's IDs do not match, so 
        the sections and other elements are identified by their titles when merging.
        If anything goes wrong during the conversion, the model remains untouched.
        """
        if not self._mdl.prjFile:
            return

        timelinePath = f'{os.path.splitext(self._mdl.prjFile.filePath)[0]}{JsonTimeline2.EXTENSION}'
        if not os.path.isfile(timelinePath):
            self._ui.set_status(_('!No {} file available for this project.').format(self.FEATURE))
            return

        if not self._ui.ask_yes_no(_('Save the project and update it?')):
            return

        self._ctrl.save_project()
        kwargs = self._get_configuration(timelinePath)
        kwargs['nv_service'] = self._mdl.nvService
        source = JsonTimeline2(timelinePath, **kwargs)
        target = self._mdl.nvService.new_novx_file(self._mdl.prjFile.filePath, **kwargs)
        try:
            target.novel = self._mdl.nvService.new_novel()
            target.read()
            source.novel = target.novel
            source.read()
            target.novel = source.novel
            target.write()
            message = f'{_("File written")}: "{norm_path(target.filePath)}".'
            self._ctrl.open_project(filePath=self._mdl.prjFile.filePath, doNotSave=True)
        except Error as ex:
            message = f'!{str(ex)}'
        self._ui.set_status(f'{message}')

    def _info(self):
        if not self._mdl.prjFile:
            return

        timelinePath = f'{os.path.splitext(self._mdl.prjFile.filePath)[0]}{JsonTimeline2.EXTENSION}'
        if os.path.isfile(timelinePath):
            try:
                timestamp = os.path.getmtime(timelinePath)
                if timestamp > self._mdl.prjFile.timestamp:
                    cmp = _('newer')
                else:
                    cmp = _('older')
                fileDate = datetime.fromtimestamp(timestamp).strftime('%c')
                message = _('{0} file is {1} than the novelibre project.\n (last saved on {2})').format(self.FEATURE, cmp, fileDate)
            except:
                message = _('Cannot determine file date.')
        else:
            message = _('No {} file available for this project.').format(self.FEATURE)
        messagebox.showinfo(f'{self.FEATURE}', message)

    def _launch_application(self):
        if not self._mdl.prjFile:
            return

        timelinePath = f'{os.path.splitext(self._mdl.prjFile.filePath)[0]}{JsonTimeline2.EXTENSION}'
        if os.path.isfile(timelinePath):
            if self.OPTIONS['lock_on_export']:
                self._ctrl.lock()
            open_document(timelinePath)
        else:
            self._ui.set_status(_('!No {} file available for this project.').format(self.FEATURE))

