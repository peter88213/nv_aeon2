"""Aeon Timeline 2 sync plugin for noveltree.

Version 2.0.0
Requires Python 3.6+
Copyright (c) 2024 Peter Triesberger
For further information see https://github.com/peter88213/nv_aeon2
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
from datetime import datetime
import gettext
import locale
import os
from pathlib import Path
import sys
from tkinter import filedialog
from tkinter import messagebox
import webbrowser

from configparser import ConfigParser


class Configuration:

    def __init__(self, settings={}, options={}):
        self.settings = None
        self.options = None
        self._sLabel = 'SETTINGS'
        self._oLabel = 'OPTIONS'
        self.set(settings, options)

    def read(self, iniFile):
        config = ConfigParser()
        config.read(iniFile, encoding='utf-8')
        if config.has_section(self._sLabel):
            section = config[self._sLabel]
            for setting in self.settings:
                fallback = self.settings[setting]
                self.settings[setting] = section.get(setting, fallback)
        if config.has_section(self._oLabel):
            section = config[self._oLabel]
            for option in self.options:
                fallback = self.options[option]
                self.options[option] = section.getboolean(option, fallback)

    def set(self, settings=None, options=None):
        if settings is not None:
            self.settings = settings.copy()
        if options is not None:
            self.options = options.copy()

    def write(self, iniFile):
        config = ConfigParser()
        if self.settings:
            config.add_section(self._sLabel)
            for settingId in self.settings:
                config.set(self._sLabel, settingId, str(self.settings[settingId]))
        if self.options:
            config.add_section(self._oLabel)
            for settingId in self.options:
                if self.options[settingId]:
                    config.set(self._oLabel, settingId, 'Yes')
                else:
                    config.set(self._oLabel, settingId, 'No')
        with open(iniFile, 'w', encoding='utf-8') as f:
            config.write(f)


ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
ARC_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
ARC_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
AC_ROOT = f'{ROOT_PREFIX}{ARC_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOT_SUFFIX = '_plot'
PROJECTNOTES_SUFFIX = '_projectnote_report'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist_tmp'
SECTIONS_SUFFIX = '_sections_tmp'
XREF_SUFFIX = '_xref'


class Error(Exception):
    pass


LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('noveltree', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

WEEKDAYS = [
    _('Monday'),
    _('Tuesday'),
    _('Wednesday'),
    _('Thursday'),
    _('Friday'),
    _('Saturday'),
    _('Sunday')
    ]


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''



def open_document(document):
    try:
        os.startfile(norm_path(document))
    except:
        try:
            os.system('xdg-open "%s"' % norm_path(document))
        except:
            try:
                os.system('open "%s"' % norm_path(document))
            except:
                pass
from datetime import date
import re



class BasicElement:

    def __init__(self,
            on_element_change=None,
            title=None,
            desc=None):
        if on_element_change is None:
            self.on_element_change = self.do_nothing
        else:
            self.on_element_change = on_element_change
        self._title = title
        self._desc = desc

    @property
    def title(self):
        return self._title

    @title.setter
    def title(self, newVal):
        if self._title != newVal:
            self._title = newVal
            self.on_element_change()

    @property
    def desc(self):
        return self._desc

    @desc.setter
    def desc(self, newVal):
        if self._desc != newVal:
            self._desc = newVal
            self.on_element_change()

    def do_nothing(self):
        pass


LANGUAGE_TAG = re.compile('\<span xml\:lang=\"(.*?)\"\>')


class Novel(BasicElement):

    def __init__(self,
            authorName=None,
            wordTarget=None,
            wordCountStart=None,
            languageCode=None,
            countryCode=None,
            renumberChapters=None,
            renumberParts=None,
            renumberWithinParts=None,
            romanChapterNumbers=None,
            romanPartNumbers=None,
            saveWordCount=None,
            workPhase=None,
            chapterHeadingPrefix=None,
            chapterHeadingSuffix=None,
            partHeadingPrefix=None,
            partHeadingSuffix=None,
            customGoal=None,
            customConflict=None,
            customOutcome=None,
            customChrBio=None,
            customChrGoals=None,
            referenceDate=None,
            tree=None,
            **kwargs):
        super().__init__(**kwargs)
        self._authorName = authorName
        self._wordTarget = wordTarget
        self._wordCountStart = wordCountStart
        self._languageCode = languageCode
        self._countryCode = countryCode
        self._renumberChapters = renumberChapters
        self._renumberParts = renumberParts
        self._renumberWithinParts = renumberWithinParts
        self._romanChapterNumbers = romanChapterNumbers
        self._romanPartNumbers = romanPartNumbers
        self._saveWordCount = saveWordCount
        self._workPhase = workPhase
        self._chapterHeadingPrefix = chapterHeadingPrefix
        self._chapterHeadingSuffix = chapterHeadingSuffix
        self._partHeadingPrefix = partHeadingPrefix
        self._partHeadingSuffix = partHeadingSuffix
        self._customGoal = customGoal
        self._customConflict = customConflict
        self._customOutcome = customOutcome
        self._customChrBio = customChrBio
        self._customChrGoals = customChrGoals

        self.chapters = {}
        self.sections = {}
        self.turningPoints = {}
        self.languages = None
        self.arcs = {}
        self.locations = {}
        self.items = {}
        self.characters = {}
        self.projectNotes = {}
        try:
            self.referenceWeekDay = date.fromisoformat(referenceDate).weekday()
            self._referenceDate = referenceDate
        except:
            self.referenceWeekDay = None
            self._referenceDate = None
        self.tree = tree

    @property
    def authorName(self):
        return self._authorName

    @authorName.setter
    def authorName(self, newVal):
        if self._authorName != newVal:
            self._authorName = newVal
            self.on_element_change()

    @property
    def wordTarget(self):
        return self._wordTarget

    @wordTarget.setter
    def wordTarget(self, newVal):
        if self._wordTarget != newVal:
            self._wordTarget = newVal
            self.on_element_change()

    @property
    def wordCountStart(self):
        return self._wordCountStart

    @wordCountStart.setter
    def wordCountStart(self, newVal):
        if self._wordCountStart != newVal:
            self._wordCountStart = newVal
            self.on_element_change()

    @property
    def languageCode(self):
        return self._languageCode

    @languageCode.setter
    def languageCode(self, newVal):
        if self._languageCode != newVal:
            self._languageCode = newVal
            self.on_element_change()

    @property
    def countryCode(self):
        return self._countryCode

    @countryCode.setter
    def countryCode(self, newVal):
        if self._countryCode != newVal:
            self._countryCode = newVal
            self.on_element_change()

    @property
    def renumberChapters(self):
        return self._renumberChapters

    @renumberChapters.setter
    def renumberChapters(self, newVal):
        if self._renumberChapters != newVal:
            self._renumberChapters = newVal
            self.on_element_change()

    @property
    def renumberParts(self):
        return self._renumberParts

    @renumberParts.setter
    def renumberParts(self, newVal):
        if self._renumberParts != newVal:
            self._renumberParts = newVal
            self.on_element_change()

    @property
    def renumberWithinParts(self):
        return self._renumberWithinParts

    @renumberWithinParts.setter
    def renumberWithinParts(self, newVal):
        if self._renumberWithinParts != newVal:
            self._renumberWithinParts = newVal
            self.on_element_change()

    @property
    def romanChapterNumbers(self):
        return self._romanChapterNumbers

    @romanChapterNumbers.setter
    def romanChapterNumbers(self, newVal):
        if self._romanChapterNumbers != newVal:
            self._romanChapterNumbers = newVal
            self.on_element_change()

    @property
    def romanPartNumbers(self):
        return self._romanPartNumbers

    @romanPartNumbers.setter
    def romanPartNumbers(self, newVal):
        if self._romanPartNumbers != newVal:
            self._romanPartNumbers = newVal
            self.on_element_change()

    @property
    def saveWordCount(self):
        return self._saveWordCount

    @saveWordCount.setter
    def saveWordCount(self, newVal):
        if self._saveWordCount != newVal:
            self._saveWordCount = newVal
            self.on_element_change()

    @property
    def workPhase(self):
        return self._workPhase

    @workPhase.setter
    def workPhase(self, newVal):
        if self._workPhase != newVal:
            self._workPhase = newVal
            self.on_element_change()

    @property
    def chapterHeadingPrefix(self):
        return self._chapterHeadingPrefix

    @chapterHeadingPrefix.setter
    def chapterHeadingPrefix(self, newVal):
        if self._chapterHeadingPrefix != newVal:
            self._chapterHeadingPrefix = newVal
            self.on_element_change()

    @property
    def chapterHeadingSuffix(self):
        return self._chapterHeadingSuffix

    @chapterHeadingSuffix.setter
    def chapterHeadingSuffix(self, newVal):
        if self._chapterHeadingSuffix != newVal:
            self._chapterHeadingSuffix = newVal
            self.on_element_change()

    @property
    def partHeadingPrefix(self):
        return self._partHeadingPrefix

    @partHeadingPrefix.setter
    def partHeadingPrefix(self, newVal):
        if self._partHeadingPrefix != newVal:
            self._partHeadingPrefix = newVal
            self.on_element_change()

    @property
    def partHeadingSuffix(self):
        return self._partHeadingSuffix

    @partHeadingSuffix.setter
    def partHeadingSuffix(self, newVal):
        if self._partHeadingSuffix != newVal:
            self._partHeadingSuffix = newVal
            self.on_element_change()

    @property
    def customGoal(self):
        return self._customGoal

    @customGoal.setter
    def customGoal(self, newVal):
        if self._customGoal != newVal:
            self._customGoal = newVal
            self.on_element_change()

    @property
    def customConflict(self):
        return self._customConflict

    @customConflict.setter
    def customConflict(self, newVal):
        if self._customConflict != newVal:
            self._customConflict = newVal
            self.on_element_change()

    @property
    def customOutcome(self):
        return self._customOutcome

    @customOutcome.setter
    def customOutcome(self, newVal):
        if self._customOutcome != newVal:
            self._customOutcome = newVal
            self.on_element_change()

    @property
    def customChrBio(self):
        return self._customChrBio

    @customChrBio.setter
    def customChrBio(self, newVal):
        if self._customChrBio != newVal:
            self._customChrBio = newVal
            self.on_element_change()

    @property
    def customChrGoals(self):
        return self._customChrGoals

    @customChrGoals.setter
    def customChrGoals(self, newVal):
        if self._customChrGoals != newVal:
            self._customChrGoals = newVal
            self.on_element_change()

    @property
    def referenceDate(self):
        return self._referenceDate

    @referenceDate.setter
    def referenceDate(self, newVal):
        if self._referenceDate != newVal:
            if not newVal:
                self._referenceDate = None
                self.referenceWeekDay = None
            else:
                try:
                    self.referenceWeekDay = date.fromisoformat(newVal).weekday()
                except:
                    pass
                else:
                    self._referenceDate = newVal
                    self.on_element_change()

    def update_section_arcs(self):
        for scId in self.sections:
            self.sections[scId].scTurningPoints = {}
            self.sections[scId].scArcs = []
            for acId in self.arcs:
                if scId in self.arcs[acId].sections:
                    self.sections[scId].scArcs.append(acId)
                    for tpId in self.tree.get_children(acId):
                        if self.turningPoints[tpId].sectionAssoc == scId:
                            self.sections[scId].scTurningPoints[tpId] = acId
                            break

    def get_languages(self):

        def languages(text):
            if text:
                m = LANGUAGE_TAG.search(text)
                while m:
                    text = text[m.span()[1]:]
                    yield m.group(1)
                    m = LANGUAGE_TAG.search(text)

        self.languages = []
        for scId in self.sections:
            text = self.sections[scId].sectionContent
            if text:
                for language in languages(text):
                    if not language in self.languages:
                        self.languages.append(language)

    def check_locale(self):
        if not self._languageCode or self._languageCode == 'None':
            try:
                sysLng, sysCtr = locale.getlocale()[0].split('_')
            except:
                sysLng, sysCtr = locale.getdefaultlocale()[0].split('_')
            self._languageCode = sysLng
            self._countryCode = sysCtr
            self.on_element_change()
            return

        try:
            if len(self._languageCode) == 2:
                if len(self._countryCode) == 2:
                    return
        except:
            pass
        self._languageCode = 'zxx'
        self._countryCode = 'none'
        self.on_element_change()



class NvTree:

    def __init__(self):
        self.roots = {
            CH_ROOT:[],
            CR_ROOT:[],
            LC_ROOT:[],
            IT_ROOT:[],
            AC_ROOT:[],
            PN_ROOT:[],
            }
        self.srtSections = {}
        self.srtTurningPoints = {}

    def append(self, parent, iid):
        if parent in self.roots:
            self.roots[parent].append(iid)
            if parent == CH_ROOT:
                self.srtSections[iid] = []
            elif parent == AC_ROOT:
                self.srtTurningPoints[iid] = []
        elif parent.startswith(CHAPTER_PREFIX):
            try:
                self.srtSections[parent].append(iid)
            except:
                self.srtSections[parent] = [iid]
        elif parent.startswith(ARC_PREFIX):
            try:
                self.srtTurningPoints[parent].append(iid)
            except:
                self.srtTurningPoints[parent] = [iid]

    def delete(self, *items):
        raise NotImplementedError

    def delete_children(self, parent):
        if parent in self.roots:
            self.roots[parent] = []
            if parent == CH_ROOT:
                self.srtSections = {}
            elif parent == AC_ROOT:
                self.srtTurningPoints = {}
        elif parent.startswith(CHAPTER_PREFIX):
            self.srtSections[parent] = []
        elif parent.startswith(ARC_PREFIX):
            self.srtTurningPoints[parent] = []

    def get_children(self, item):
        if item in self.roots:
            return self.roots[item]

        elif item.startswith(CHAPTER_PREFIX):
            return self.srtSections.get(item, [])

        elif item.startswith(ARC_PREFIX):
            return self.srtTurningPoints.get(item, [])

    def index(self, item):
        raise NotImplementedError

    def insert(self, parent, index, iid):
        if parent in self.roots:
            self.roots[parent].insert(index, iid)
            if parent == CH_ROOT:
                self.srtSections[iid] = []
            elif parent == AC_ROOT:
                self.srtTurningPoints[iid] = []
        elif parent.startswith(CHAPTER_PREFIX):
            try:
                self.srtSections[parent].insert(index, iid)
            except:
                self.srtSections[parent] = [iid]
        elif parent.startswith(ARC_PREFIX):
            try:
                self.srtTurningPoints.insert(index, iid)
            except:
                self.srtTurningPoints[parent] = [iid]

    def move(self, item, parent, index):
        raise NotImplementedError

    def next(self, item):
        raise NotImplementedError

    def parent(self, item):
        raise NotImplementedError

    def prev(self, item):
        raise NotImplementedError

    def reset(self):
        for item in self.roots:
            self.roots[item] = []
        self.srtSections = {}
        self.srtTurningPoints = {}

    def set_children(self, item, newchildren):
        if item in self.roots:
            self.roots[item] = newchildren[:]
            if item == CH_ROOT:
                self.srtSections = {}
            elif item == AC_ROOT:
                self.srtTurningPoints = {}
        elif item.startswith(CHAPTER_PREFIX):
            self.srtSections[item] = newchildren[:]
        elif item.startswith(ARC_PREFIX):
            self.srtTurningPoints[item] = newchildren[:]


from datetime import date
from datetime import time

from abc import ABC
from urllib.parse import quote



class File(ABC):
    DESCRIPTION = _('File')
    EXTENSION = None
    SUFFIX = None

    PRJ_KWVAR = [
        'Field_ChapterHeadingPrefix',
        'Field_ChapterHeadingSuffix',
        'Field_PartHeadingPrefix',
        'Field_PartHeadingSuffix',
        'Field_CustomGoal',
        'Field_CustomConflict',
        'Field_CustomOutcome',
        'Field_CustomChrBio',
        'Field_CustomChrGoals',
        ]

    def __init__(self, filePath, **kwargs):
        self.novel = None
        self._filePath = None
        self.projectName = None
        self.projectPath = None
        self.sectionsSplit = False
        self.filePath = filePath

    @property
    def filePath(self):
        return self._filePath

    @filePath.setter
    def filePath(self, filePath: str):
        if self.SUFFIX is not None:
            suffix = self.SUFFIX
        else:
            suffix = ''
        if filePath.lower().endswith(f'{suffix}{self.EXTENSION}'.lower()):
            self._filePath = filePath
            try:
                head, tail = os.path.split(os.path.realpath(filePath))
            except:
                head, tail = os.path.split(filePath)
            self.projectPath = quote(head.replace('\\', '/'), '/:')
            self.projectName = quote(tail.replace(f'{suffix}{self.EXTENSION}', ''))

    def is_locked(self):
        return False

    def read(self):
        raise NotImplementedError

    def write(self):
        raise NotImplementedError



class Arc(BasicElement):

    def __init__(self,
            shortName=None,
            **kwargs):
        super().__init__(**kwargs)

        self._shortName = shortName

        self._sections = None

    @property
    def shortName(self):
        return self._shortName

    @shortName.setter
    def shortName(self, newVal):
        if self._shortName != newVal:
            self._shortName = newVal
            self.on_element_change()

    @property
    def sections(self):
        try:
            return self._sections[:]
        except TypeError:
            return None

    @sections.setter
    def sections(self, newVal):
        if self._sections != newVal:
            self._sections = newVal
            self.on_element_change()



class Chapter(BasicElement):

    def __init__(self,
            chLevel=None,
            chType=None,
            noNumber=None,
            isTrash=None,
            **kwargs):
        super().__init__(**kwargs)
        self._chLevel = chLevel
        self._chType = chType
        self._noNumber = noNumber
        self._isTrash = isTrash

    @property
    def chLevel(self):
        return self._chLevel

    @chLevel.setter
    def chLevel(self, newVal):
        if self._chLevel != newVal:
            self._chLevel = newVal
            self.on_element_change()

    @property
    def chType(self):
        return self._chType

    @chType.setter
    def chType(self, newVal):
        if self._chType != newVal:
            self._chType = newVal
            self.on_element_change()

    @property
    def noNumber(self):
        return self._noNumber

    @noNumber.setter
    def noNumber(self, newVal):
        if self._noNumber != newVal:
            self._noNumber = newVal
            self.on_element_change()

    @property
    def isTrash(self):
        return self._isTrash

    @isTrash.setter
    def isTrash(self, newVal):
        if self._isTrash != newVal:
            self._isTrash = newVal
            self.on_element_change()


class WorldElement(BasicElement):

    def __init__(self,
            aka=None,
            tags=None,
            links=None,
            **kwargs):
        super().__init__(**kwargs)
        self._aka = aka
        self._tags = tags
        self._links = links

    @property
    def aka(self):
        return self._aka

    @aka.setter
    def aka(self, newVal):
        if self._aka != newVal:
            self._aka = newVal
            self.on_element_change()

    @property
    def tags(self):
        return self._tags

    @tags.setter
    def tags(self, newVal):
        if self._tags != newVal:
            self._tags = newVal
            self.on_element_change()

    @property
    def links(self):
        try:
            return self._links.copy()
        except AttributeError:
            return None

    @links.setter
    def links(self, newVal):
        if self._links != newVal:
            self._links = newVal
            for linkPath in newVal:
                self._links[linkPath] = os.path.split(linkPath)[1]
            self.on_element_change()



class Character(WorldElement):
    MAJOR_MARKER = 'Major'
    MINOR_MARKER = 'Minor'

    def __init__(self,
            notes=None,
            bio=None,
            goals=None,
            fullName=None,
            isMajor=None,
            birthDate=None,
            deathDate=None,
            **kwargs):
        super().__init__(**kwargs)
        self._notes = notes
        self._bio = bio
        self._goals = goals
        self._fullName = fullName
        self._isMajor = isMajor
        self._birthDate = birthDate
        self._deathDate = deathDate

    @property
    def notes(self):
        return self._notes

    @notes.setter
    def notes(self, newVal):
        if self._notes != newVal:
            self._notes = newVal
            self.on_element_change()

    @property
    def bio(self):
        return self._bio

    @bio.setter
    def bio(self, newVal):
        if self._bio != newVal:
            self._bio = newVal
            self.on_element_change()

    @property
    def goals(self):
        return self._goals

    @goals.setter
    def goals(self, newVal):
        if self._goals != newVal:
            self._goals = newVal
            self.on_element_change()

    @property
    def fullName(self):
        return self._fullName

    @fullName.setter
    def fullName(self, newVal):
        if self._fullName != newVal:
            self._fullName = newVal
            self.on_element_change()

    @property
    def isMajor(self):
        return self._isMajor

    @isMajor.setter
    def isMajor(self, newVal):
        if self._isMajor != newVal:
            self._isMajor = newVal
            self.on_element_change()

    @property
    def birthDate(self):
        return self._birthDate

    @birthDate.setter
    def birthDate(self, newVal):
        if self._birthDate != newVal:
            self._birthDate = newVal
            self.on_element_change()

    @property
    def deathDate(self):
        return self._deathDate

    @deathDate.setter
    def deathDate(self, newVal):
        if self._deathDate != newVal:
            self._deathDate = newVal
            self.on_element_change()

from datetime import datetime, date, timedelta


ADDITIONAL_WORD_LIMITS = re.compile('--|—|–|\<\/p\>')

NO_WORD_LIMITS = re.compile('\<note\>.*?\<\/note\>|\<comment\>.*?\<\/comment\>|\<.+?\>')


class Section(BasicElement):
    PACING = ['A', 'R', 'C']

    NULL_DATE = '0001-01-01'
    NULL_TIME = '00:00:00'

    def __init__(self,
            scType=None,
            scPacing=None,
            status=None,
            notes=None,
            tags=None,
            appendToPrev=None,
            goal=None,
            conflict=None,
            outcome=None,
            scDate=None,
            scTime=None,
            day=None,
            lastsMinutes=None,
            lastsHours=None,
            lastsDays=None,
            characters=None,
            locations=None,
            items=None,
            **kwargs):
        super().__init__(**kwargs)
        self._sectionContent = None
        self.wordCount = 0
        self._scType = scType
        self._scPacing = scPacing
        self._status = status
        self._notes = notes
        self._tags = tags
        self._appendToPrev = appendToPrev
        self._goal = goal
        self._conflict = conflict
        self._outcome = outcome

        try:
            self.weekDay = date.fromisoformat(scDate).weekday()
            self._date = scDate
        except:
            self.weekDay = None
            self._date = None

        self._time = scTime

        self._day = day
        self._lastsMinutes = lastsMinutes
        self._lastsHours = lastsHours
        self._lastsDays = lastsDays

        self._characters = characters
        self._locations = locations
        self._items = items

        self.scArcs = []
        self.scTurningPoints = {}

    @property
    def sectionContent(self):
        return self._sectionContent

    @sectionContent.setter
    def sectionContent(self, text):
        if self._sectionContent != text:
            self._sectionContent = text
            if text is not None:
                text = ADDITIONAL_WORD_LIMITS.sub(' ', text)
                text = NO_WORD_LIMITS.sub('', text)
                wordList = text.split()
                self.wordCount = len(wordList)
            else:
                self.wordCount = 0
            self.on_element_change()

    @property
    def scType(self):
        return self._scType

    @scType.setter
    def scType(self, newVal):
        if self._scType != newVal:
            self._scType = newVal
            self.on_element_change()

    @property
    def scPacing(self):
        return self._scPacing

    @scPacing.setter
    def scPacing(self, newVal):
        if self._scPacing != newVal:
            self._scPacing = newVal
            self.on_element_change()

    @property
    def status(self):
        return self._status

    @status.setter
    def status(self, newVal):
        if self._status != newVal:
            self._status = newVal
            self.on_element_change()

    @property
    def notes(self):
        return self._notes

    @notes.setter
    def notes(self, newVal):
        if self._notes != newVal:
            self._notes = newVal
            self.on_element_change()

    @property
    def tags(self):
        return self._tags

    @tags.setter
    def tags(self, newVal):
        if self._tags != newVal:
            self._tags = newVal
            self.on_element_change()

    @property
    def appendToPrev(self):
        return self._appendToPrev

    @appendToPrev.setter
    def appendToPrev(self, newVal):
        if self._appendToPrev != newVal:
            self._appendToPrev = newVal
            self.on_element_change()

    @property
    def goal(self):
        return self._goal

    @goal.setter
    def goal(self, newVal):
        if self._goal != newVal:
            self._goal = newVal
            self.on_element_change()

    @property
    def conflict(self):
        return self._conflict

    @conflict.setter
    def conflict(self, newVal):
        if self._conflict != newVal:
            self._conflict = newVal
            self.on_element_change()

    @property
    def outcome(self):
        return self._outcome

    @outcome.setter
    def outcome(self, newVal):
        if self._outcome != newVal:
            self._outcome = newVal
            self.on_element_change()

    @property
    def date(self):
        return self._date

    @date.setter
    def date(self, newVal):
        if self._date != newVal:
            if not newVal:
                self._date = None
                self.weekDay = None
            else:
                try:
                    self.weekDay = date.fromisoformat(newVal).weekday()
                except:
                    pass
                else:
                    self._date = newVal
                    self.on_element_change()

    @property
    def time(self):
        return self._time

    @time.setter
    def time(self, newVal):
        if self._time != newVal:
            self._time = newVal
            self.on_element_change()

    @property
    def day(self):
        return self._day

    @day.setter
    def day(self, newVal):
        if self._day != newVal:
            self._day = newVal
            self.on_element_change()

    @property
    def lastsMinutes(self):
        return self._lastsMinutes

    @lastsMinutes.setter
    def lastsMinutes(self, newVal):
        if self._lastsMinutes != newVal:
            self._lastsMinutes = newVal
            self.on_element_change()

    @property
    def lastsHours(self):
        return self._lastsHours

    @lastsHours.setter
    def lastsHours(self, newVal):
        if self._lastsHours != newVal:
            self._lastsHours = newVal
            self.on_element_change()

    @property
    def lastsDays(self):
        return self._lastsDays

    @lastsDays.setter
    def lastsDays(self, newVal):
        if self._lastsDays != newVal:
            self._lastsDays = newVal
            self.on_element_change()

    @property
    def characters(self):
        try:
            return self._characters[:]
        except TypeError:
            return None

    @characters.setter
    def characters(self, newVal):
        if self._characters != newVal:
            self._characters = newVal
            self.on_element_change()

    @property
    def locations(self):
        try:
            return self._locations[:]
        except TypeError:
            return None

    @locations.setter
    def locations(self, newVal):
        if self._locations != newVal:
            self._locations = newVal
            self.on_element_change()

    @property
    def items(self):
        try:
            return self._items[:]
        except TypeError:
            return None

    @items.setter
    def items(self, newVal):
        if self._items != newVal:
            self._items = newVal
            self.on_element_change()

    def get_end_date_time(self):
        endDate = None
        endTime = None
        endDay = None
        if self.lastsDays:
            lastsDays = int(self.lastsDays)
        else:
            lastsDays = 0
        if self.lastsHours:
            lastsSeconds = int(self.lastsHours) * 3600
        else:
            lastsSeconds = 0
        if self.lastsMinutes:
            lastsSeconds += int(self.lastsMinutes) * 60
        sectionDuration = timedelta(days=lastsDays, seconds=lastsSeconds)
        if self.time:
            if self.date:
                try:
                    sectionStart = datetime.fromisoformat(f'{self.date} {self.time}')
                    sectionEnd = sectionStart + sectionDuration
                    endDate, endTime = sectionEnd.isoformat().split('T')
                except:
                    pass
            else:
                try:
                    if self.day:
                        dayInt = int(self.day)
                    else:
                        dayInt = 0
                    startDate = (date.min + timedelta(days=dayInt)).isoformat()
                    sectionStart = datetime.fromisoformat(f'{startDate} {self.time}')
                    sectionEnd = sectionStart + sectionDuration
                    endDate, endTime = sectionEnd.isoformat().split('T')
                    endDay = str((date.fromisoformat(endDate) - date.min).days)
                    endDate = None
                except:
                    pass
        return endDate, endTime, endDay

    def day_to_date(self, referenceDate):
        if not self._date:
            try:
                deltaDays = timedelta(days=int(self._day))
                refDate = date.fromisoformat(referenceDate)
                self.date = date.isoformat(refDate + deltaDays)
                self._day = None
            except:
                self.date = ''
                return False

        return True

    def date_to_day(self, referenceDate):
        if not self._day:
            try:
                sectionDate = date.fromisoformat(self._date)
                referenceDate = date.fromisoformat(referenceDate)
                self.day = str((sectionDate - referenceDate).days)
                self._date = None
                self.weekDay = None
            except:
                self.day = ''
                return False

        return True



class TurningPoint(BasicElement):

    def __init__(self,
            sectionAssoc=None,
            notes=None,
            **kwargs):
        super().__init__(**kwargs)

        self._sectionAssoc = sectionAssoc

        self._notes = notes

    @property
    def sectionAssoc(self):
        return self._sectionAssoc

    @sectionAssoc.setter
    def sectionAssoc(self, newVal):
        if self._sectionAssoc != newVal:
            self._sectionAssoc = newVal
            self.on_element_change()

    @property
    def notes(self):
        return self._notes

    @notes.setter
    def notes(self, newVal):
        if self._notes != newVal:
            self._notes = newVal
            self.on_element_change()

import xml.etree.ElementTree as ET

__all__ = [
    'get_element_text',
    'text_to_xml_element',
    'xml_element_to_text',
    ]


def get_element_text(parent, tag, default=None):
    if parent.find(tag) is not None:
        return parent.find(tag).text
    else:
        return default


def text_to_xml_element(tag, text):
    xmlElement = ET.Element(tag)
    for line in text.split('\n'):
        ET.SubElement(xmlElement, 'p').text = line
    return xmlElement


def xml_element_to_text(xmlElement):
    lines = []
    if xmlElement:
        for paragraph in xmlElement.iterfind('p'):
            lines.append(''.join(t for t in paragraph.itertext()))
    return '\n'.join(lines)



def indent(elem, level=0):
    i = f'\n{level * "  "}'
    if elem:
        if not elem.text or not elem.text.strip():
            elem.text = f'{i}  '
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        for elem in elem:
            indent(elem, level + 1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i


class NovxFile(File):
    DESCRIPTION = _('noveltree project')
    EXTENSION = '.novx'

    MAJOR_VERSION = 1
    MINOR_VERSION = 0

    XML_HEADER = '''<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE novx SYSTEM "novx_1_0.dtd">
<?xml-stylesheet href="novx.css" type="text/css"?>
'''

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self.on_element_change = None
        self.xmlTree = None
        self.wcLog = {}
        self.wcLogUpdate = {}

    def adjust_section_types(self):
        partType = 0
        for chId in self.novel.tree.get_children(CH_ROOT):
            if self.novel.chapters[chId].chLevel == 1:
                partType = self.novel.chapters[chId].chType
            elif partType != 0 and not self.novel.chapters[chId].isTrash:
                self.novel.chapters[chId].chType = partType
            for scId in self.novel.tree.get_children(chId):
                if self.novel.sections[scId].scType < self.novel.chapters[chId].chType:
                    self.novel.sections[scId].scType = self.novel.chapters[chId].chType

    def count_words(self):
        count = 0
        totalCount = 0
        for chId in self.novel.tree.get_children(CH_ROOT):
            if not self.novel.chapters[chId].isTrash:
                for scId in self.novel.tree.get_children(chId):
                    if self.novel.sections[scId].scType < 2:
                        totalCount += self.novel.sections[scId].wordCount
                        if self.novel.sections[scId].scType == 0:
                            count += self.novel.sections[scId].wordCount
        return count, totalCount

    def read(self):
        self.xmlTree = ET.parse(self.filePath)
        xmlRoot = self.xmlTree.getroot()
        try:
            majorVersionStr, minorVersionStr = xmlRoot.attrib['version'].split('.')
            majorVersion = int(majorVersionStr)
            minorVersion = int(minorVersionStr)
        except:
            raise Error(f'{_("No valid version found in file")}: "{norm_path(self.filePath)}".')

        if majorVersion > self.MAJOR_VERSION:
            raise Error(_('The project "{}" was created with a newer noveltree version.').format(norm_path(self.filePath)))

        elif majorVersion < self.MAJOR_VERSION:
            raise Error(_('The project "{}" was created with an outdated noveltree version.').format(norm_path(self.filePath)))

        elif minorVersion > self.MINOR_VERSION:
            raise Error(_('The project "{}" was created with a newer noveltree version.').format(norm_path(self.filePath)))

        try:
            locale = xmlRoot.attrib['{http://www.w3.org/XML/1998/namespace}lang']
            self.novel.languageCode, self.novel.countryCode = locale.split('-')
        except:
            pass
        self.novel.tree.reset()
        self._read_project(xmlRoot)
        self._read_locations(xmlRoot)
        self._read_items(xmlRoot)
        self._read_characters(xmlRoot)
        self._read_chapters(xmlRoot)
        self._read_arcs(xmlRoot)
        self._read_projectnotes(xmlRoot)
        self.adjust_section_types()

        xmlWclog = xmlRoot.find('PROGRESS')
        if xmlWclog is not None:
            for xmlWc in xmlWclog.iterfind('WC'):
                wcDate = xmlWc.find('Date').text
                wcCount = xmlWc.find('Count').text
                wcTotalCount = xmlWc.find('WithUnused').text
                if wcDate and wcCount and wcTotalCount:
                    self.wcLog[wcDate] = [wcCount, wcTotalCount]

    def write(self):
        if self.novel.saveWordCount:
            newCountInt, newTotalCountInt = self.count_words()
            newCount = str(newCountInt)
            newTotalCount = str(newTotalCountInt)
            today = date.today().isoformat()
            self.wcLogUpdate[today] = [newCount, newTotalCount]
            for wcDate in self.wcLogUpdate:
                self.wcLog[wcDate] = self.wcLogUpdate[wcDate]
        self.wcLogUpdate = {}
        self.adjust_section_types()
        self.novel.get_languages()
        attrib = {'version':f'{self.MAJOR_VERSION}.{self.MINOR_VERSION}',
                'xml:lang':f'{self.novel.languageCode}-{self.novel.countryCode}',
                }
        xmlRoot = ET.Element('novx', attrib=attrib)
        self._build_element_tree(xmlRoot)
        indent(xmlRoot)
        self.xmlTree = ET.ElementTree(xmlRoot)
        self._write_element_tree(self)
        self._postprocess_xml_file(self.filePath)

    def _build_arc_branch(self, xmlArcs, prjArc, acId):
        xmlArc = ET.SubElement(xmlArcs, 'ARC', attrib={'id':acId})
        if prjArc.title:
            ET.SubElement(xmlArc, 'Title').text = prjArc.title
        if prjArc.shortName:
            ET.SubElement(xmlArc, 'ShortName').text = prjArc.shortName
        if prjArc.desc:
            xmlArc.append(text_to_xml_element('Desc', prjArc.desc))

        if prjArc.sections:
            attrib = {'ids':' '.join(prjArc.sections)}
            ET.SubElement(xmlArc, 'Sections', attrib=attrib)

        for tpId in self.novel.tree.get_children(acId):
            xmlPoint = ET.SubElement(xmlArc, 'POINT', attrib={'id':tpId})
            self._build_turningPoint_branch(xmlPoint, self.novel.turningPoints[tpId])

        return xmlArc

    def _build_turningPoint_branch(self, xmlPoint, prjTurningPoint):
        if prjTurningPoint.title:
            ET.SubElement(xmlPoint, 'Title').text = prjTurningPoint.title
        if prjTurningPoint.desc:
            xmlPoint.append(text_to_xml_element('Desc', prjTurningPoint.desc))
        if prjTurningPoint.notes:
            xmlPoint.append(text_to_xml_element('Notes', prjTurningPoint.notes))

        if prjTurningPoint.sectionAssoc:
            ET.SubElement(xmlPoint, 'Section', attrib={'id': prjTurningPoint.sectionAssoc})

    def _build_chapter_branch(self, xmlChapters, prjChp, chId):
        xmlChapter = ET.SubElement(xmlChapters, 'CHAPTER', attrib={'id':chId})
        if prjChp.chType:
            xmlChapter.set('type', str(prjChp.chType))
        if prjChp.chLevel == 1:
            xmlChapter.set('level', '1')
        if prjChp.isTrash:
            xmlChapter.set('isTrash', '1')
        if prjChp.noNumber:
            xmlChapter.set('noNumber', '1')
        if prjChp.title:
            ET.SubElement(xmlChapter, 'Title').text = prjChp.title
        if prjChp.desc:
            xmlChapter.append(text_to_xml_element('Desc', prjChp.desc))
        for scId in self.novel.tree.get_children(chId):
            xmlSection = ET.SubElement(xmlChapter, 'SECTION', attrib={'id':scId})
            self._build_section_branch(xmlSection, self.novel.sections[scId])
        return xmlChapter

    def _build_character_branch(self, xmlCrt, prjCrt):
        if prjCrt.isMajor:
            xmlCrt.set('major', '1')
        if prjCrt.title:
            ET.SubElement(xmlCrt, 'Title').text = prjCrt.title
        if prjCrt.fullName:
            ET.SubElement(xmlCrt, 'FullName').text = prjCrt.fullName
        if prjCrt.aka:
            ET.SubElement(xmlCrt, 'Aka').text = prjCrt.aka
        if prjCrt.desc:
            xmlCrt.append(text_to_xml_element('Desc', prjCrt.desc))
        if prjCrt.bio:
            xmlCrt.append(text_to_xml_element('Bio', prjCrt.bio))
        if prjCrt.goals:
            xmlCrt.append(text_to_xml_element('Goals', prjCrt.goals))
        if prjCrt.notes:
            xmlCrt.append(text_to_xml_element('Notes', prjCrt.notes))
        tagStr = list_to_string(prjCrt.tags)
        if tagStr:
            ET.SubElement(xmlCrt, 'Tags').text = tagStr
        if prjCrt.links:
            for path in prjCrt.links:
                xmlLink = ET.SubElement(xmlCrt, 'Link')
                xmlLink.set('path', path)
        if prjCrt.birthDate:
            ET.SubElement(xmlCrt, 'BirthDate').text = prjCrt.birthDate
        if prjCrt.deathDate:
            ET.SubElement(xmlCrt, 'DeathDate').text = prjCrt.deathDate

    def _build_element_tree(self, root):

        xmlProject = ET.SubElement(root, 'PROJECT')
        self._build_project_branch(xmlProject)

        xmlChapters = ET.SubElement(root, 'CHAPTERS')
        for chId in self.novel.tree.get_children(CH_ROOT):
            self._build_chapter_branch(xmlChapters, self.novel.chapters[chId], chId)

        xmlCharacters = ET.SubElement(root, 'CHARACTERS')
        for crId in self.novel.tree.get_children(CR_ROOT):
            xmlCrt = ET.SubElement(xmlCharacters, 'CHARACTER', attrib={'id':crId})
            self._build_character_branch(xmlCrt, self.novel.characters[crId])

        xmlLocations = ET.SubElement(root, 'LOCATIONS')
        for lcId in self.novel.tree.get_children(LC_ROOT):
            xmlLoc = ET.SubElement(xmlLocations, 'LOCATION', attrib={'id':lcId})
            self._build_location_branch(xmlLoc, self.novel.locations[lcId])

        xmlItems = ET.SubElement(root, 'ITEMS')
        for itId in self.novel.tree.get_children(IT_ROOT):
            xmlItm = ET.SubElement(xmlItems, 'ITEM', attrib={'id':itId})
            self._build_item_branch(xmlItm, self.novel.items[itId])

        xmlArcs = ET.SubElement(root, 'ARCS')
        for acId in self.novel.tree.get_children(AC_ROOT):
            self._build_arc_branch(xmlArcs, self.novel.arcs[acId], acId)

        xmlProjectnotes = ET.SubElement(root, 'PROJECTNOTES')
        for pnId in self.novel.tree.get_children(PN_ROOT):
            xmlProjectnote = ET.SubElement(xmlProjectnotes, 'PROJECTNOTE', attrib={'id':pnId})
            self._build_projectnotes_branch(xmlProjectnote, self.novel.projectNotes[pnId])

        if self.wcLog:
            xmlWcLog = ET.SubElement(root, 'PROGRESS')
            wcLastCount = None
            wcLastTotalCount = None
            for wc in self.wcLog:
                if self.novel.saveWordCount:
                    if self.wcLog[wc][0] == wcLastCount and self.wcLog[wc][1] == wcLastTotalCount:
                        continue

                    wcLastCount = self.wcLog[wc][0]
                    wcLastTotalCount = self.wcLog[wc][1]
                xmlWc = ET.SubElement(xmlWcLog, 'WC')
                ET.SubElement(xmlWc, 'Date').text = wc
                ET.SubElement(xmlWc, 'Count').text = self.wcLog[wc][0]
                ET.SubElement(xmlWc, 'WithUnused').text = self.wcLog[wc][1]

    def _build_item_branch(self, xmlItm, prjItm):
        if prjItm.title:
            ET.SubElement(xmlItm, 'Title').text = prjItm.title
        if prjItm.aka:
            ET.SubElement(xmlItm, 'Aka').text = prjItm.aka
        if prjItm.desc:
            xmlItm.append(text_to_xml_element('Desc', prjItm.desc))
        tagStr = list_to_string(prjItm.tags)
        if tagStr:
            ET.SubElement(xmlItm, 'Tags').text = tagStr
        if prjItm.links:
            for path in prjItm.links:
                xmlLink = ET.SubElement(xmlItm, 'Link')
                xmlLink.set('path', path)

    def _build_location_branch(self, xmlLoc, prjLoc):
        if prjLoc.title:
            ET.SubElement(xmlLoc, 'Title').text = prjLoc.title
        if prjLoc.aka:
            ET.SubElement(xmlLoc, 'Aka').text = prjLoc.aka
        if prjLoc.desc:
            xmlLoc.append(text_to_xml_element('Desc', prjLoc.desc))
        tagStr = list_to_string(prjLoc.tags)
        if tagStr:
            ET.SubElement(xmlLoc, 'Tags').text = tagStr
        if prjLoc.links:
            for path in prjLoc.links:
                xmlLink = ET.SubElement(xmlLoc, 'Link')
                xmlLink.set('path', path)

    def _build_project_branch(self, xmlProject):
        if self.novel.renumberChapters:
            xmlProject.set('renumberChapters', '1')
        if self.novel.renumberParts:
            xmlProject.set('renumberParts', '1')
        if self.novel.renumberWithinParts:
            xmlProject.set('renumberWithinParts', '1')
        if self.novel.romanChapterNumbers:
            xmlProject.set('romanChapterNumbers', '1')
        if self.novel.romanPartNumbers:
            xmlProject.set('romanPartNumbers', '1')
        if self.novel.saveWordCount:
            xmlProject.set('saveWordCount', '1')
        if self.novel.workPhase is not None:
            xmlProject.set('workPhase', str(self.novel.workPhase))

        if self.novel.title:
            ET.SubElement(xmlProject, 'Title').text = self.novel.title
        if self.novel.authorName:
            ET.SubElement(xmlProject, 'Author').text = self.novel.authorName
        if self.novel.desc:
            xmlProject.append(text_to_xml_element('Desc', self.novel.desc))
        if self.novel.chapterHeadingPrefix:
            ET.SubElement(xmlProject, 'ChapterHeadingPrefix').text = self.novel.chapterHeadingPrefix
        if self.novel.chapterHeadingSuffix:
            ET.SubElement(xmlProject, 'ChapterHeadingSuffix').text = self.novel.chapterHeadingSuffix
        if self.novel.partHeadingPrefix:
            ET.SubElement(xmlProject, 'PartHeadingPrefix').text = self.novel.partHeadingPrefix
        if self.novel.partHeadingSuffix:
            ET.SubElement(xmlProject, 'PartHeadingSuffix').text = self.novel.partHeadingSuffix
        if self.novel.customGoal:
            ET.SubElement(xmlProject, 'CustomGoal').text = self.novel.customGoal
        if self.novel.customConflict:
            ET.SubElement(xmlProject, 'CustomConflict').text = self.novel.customConflict
        if self.novel.customOutcome:
            ET.SubElement(xmlProject, 'CustomOutcome').text = self.novel.customOutcome
        if self.novel.customChrBio:
            ET.SubElement(xmlProject, 'CustomChrBio').text = self.novel.customChrBio
        if self.novel.customChrGoals:
            ET.SubElement(xmlProject, 'CustomChrGoals').text = self.novel.customChrGoals
        if self.novel.wordCountStart:
            ET.SubElement(xmlProject, 'WordCountStart').text = str(self.novel.wordCountStart)
        if self.novel.wordTarget:
            ET.SubElement(xmlProject, 'WordTarget').text = str(self.novel.wordTarget)
        if self.novel.referenceDate:
            ET.SubElement(xmlProject, 'ReferenceDate').text = self.novel.referenceDate

    def _build_projectnotes_branch(self, xmlProjectnote, projectNote):
        if projectNote.title:
            ET.SubElement(xmlProjectnote, 'Title').text = projectNote.title
        if projectNote.desc:
            xmlProjectnote.append(text_to_xml_element('Desc', projectNote.desc))

    def _build_section_branch(self, xmlSection, prjScn):
        if prjScn.scType:
            xmlSection.set('type', str(prjScn.scType))
        if prjScn.status > 1:
            xmlSection.set('status', str(prjScn.status))
        if prjScn.scPacing > 0:
            xmlSection.set('pacing', str(prjScn.scPacing))
        if prjScn.appendToPrev:
            xmlSection.set('append', '1')
        if prjScn.title:
            ET.SubElement(xmlSection, 'Title').text = prjScn.title
        if prjScn.desc:
            xmlSection.append(text_to_xml_element('Desc', prjScn.desc))
        if prjScn.goal:
            xmlSection.append(text_to_xml_element('Goal', prjScn.goal))
        if prjScn.conflict:
            xmlSection.append(text_to_xml_element('Conflict', prjScn.conflict))
        if prjScn.outcome:
            xmlSection.append(text_to_xml_element('Outcome', prjScn.outcome))
        if prjScn.notes:
            xmlSection.append(text_to_xml_element('Notes', prjScn.notes))
        tagStr = list_to_string(prjScn.tags)
        if tagStr:
            ET.SubElement(xmlSection, 'Tags').text = tagStr

        if prjScn.date:
            ET.SubElement(xmlSection, 'Date').text = prjScn.date
        elif prjScn.day:
            ET.SubElement(xmlSection, 'Day').text = prjScn.day
        if prjScn.time:
            ET.SubElement(xmlSection, 'Time').text = prjScn.time

        if prjScn.lastsDays and prjScn.lastsDays != '0':
            ET.SubElement(xmlSection, 'LastsDays').text = prjScn.lastsDays
        if prjScn.lastsHours and prjScn.lastsHours != '0':
            ET.SubElement(xmlSection, 'LastsHours').text = prjScn.lastsHours
        if prjScn.lastsMinutes and prjScn.lastsMinutes != '0':
            ET.SubElement(xmlSection, 'LastsMinutes').text = prjScn.lastsMinutes

        if prjScn.characters:
            attrib = {'ids':' '.join(prjScn.characters)}
            ET.SubElement(xmlSection, 'Characters', attrib=attrib)
        if prjScn.locations:
            attrib = {'ids':' '.join(prjScn.locations)}
            ET.SubElement(xmlSection, 'Locations', attrib=attrib)
        if prjScn.items:
            attrib = {'ids':' '.join(prjScn.items)}
            ET.SubElement(xmlSection, 'Items', attrib=attrib)

        sectionContent = prjScn.sectionContent
        if sectionContent:
            if not sectionContent in ('<p></p>', '<p />'):
                xmlSection.append(ET.fromstring(f'<Content>{sectionContent}</Content>'))

    def _get_link_dict(self, parent):
        links = {}
        for xmlLink in parent.iterfind('Link'):
            path = xmlLink.attrib.get('path', None)
            if path:
                links[path] = None
        return links

    def _postprocess_xml_file(self, filePath):
        with open(filePath, 'r', encoding='utf-8') as f:
            text = f.read()
        try:
            with open(filePath, 'w', encoding='utf-8') as f:
                f.write(f'{self.XML_HEADER}{text}')
        except:
            raise Error(f'{_("Cannot write file")}: "{norm_path(filePath)}".')

    def _read_arcs(self, root):
        try:
            for xmlArc in root.find('ARCS'):
                acId = xmlArc.attrib['id']
                self.novel.arcs[acId] = Arc(on_element_change=self.on_element_change)
                self.novel.arcs[acId].title = get_element_text(xmlArc, 'Title')
                self.novel.arcs[acId].desc = xml_element_to_text(xmlArc.find('Desc'))
                self.novel.arcs[acId].shortName = get_element_text(xmlArc, 'ShortName')
                self.novel.tree.append(AC_ROOT, acId)
                for xmlPoint in xmlArc.iterfind('POINT'):
                    tpId = xmlPoint.attrib['id']
                    self._read_turningPoint(xmlPoint, tpId, acId)
                    self.novel.tree.append(acId, tpId)

                acSections = []
                xmlSections = xmlArc.find('Sections')
                if xmlSections is not None:
                    scIds = xmlSections.get('ids', None)
                    for scId in string_to_list(scIds, divider=' '):
                        if scId and scId in self.novel.sections:
                            acSections.append(scId)
                            self.novel.sections[scId].scArcs.append(acId)
                self.novel.arcs[acId].sections = acSections
        except TypeError:
            pass

    def _read_turningPoint(self, xmlPoint, tpId, acId):
        self.novel.turningPoints[tpId] = TurningPoint(on_element_change=self.on_element_change)
        self.novel.turningPoints[tpId].title = get_element_text(xmlPoint, 'Title')
        self.novel.turningPoints[tpId].desc = xml_element_to_text(xmlPoint.find('Desc'))
        self.novel.turningPoints[tpId].notes = xml_element_to_text(xmlPoint.find('Notes'))
        xmlSectionAssoc = xmlPoint.find('Section')
        if xmlSectionAssoc is not None:
            scId = xmlSectionAssoc.get('id', None)
            self.novel.turningPoints[tpId].sectionAssoc = scId
            self.novel.sections[scId].scTurningPoints[tpId] = acId

    def _read_chapters(self, root, partType=0):
        try:
            for xmlChapter in root.find('CHAPTERS'):
                chId = xmlChapter.attrib['id']
                self.novel.chapters[chId] = Chapter(on_element_change=self.on_element_change)
                typeStr = xmlChapter.get('type', '0')
                if typeStr in ('0', '1'):
                    self.novel.chapters[chId].chType = int(typeStr)
                else:
                    self.novel.chapters[chId].chType = 1
                chLevel = xmlChapter.get('level', None)
                if chLevel == '1':
                    self.novel.chapters[chId].chLevel = 1
                else:
                    self.novel.chapters[chId].chLevel = 2
                self.novel.chapters[chId].isTrash = xmlChapter.get('isTrash', None) == '1'
                self.novel.chapters[chId].noNumber = xmlChapter.get('noNumber', None) == '1'
                self.novel.chapters[chId].title = get_element_text(xmlChapter, 'Title')
                self.novel.chapters[chId].desc = xml_element_to_text(xmlChapter.find('Desc'))
                self.novel.tree.append(CH_ROOT, chId)
                if xmlChapter.find('SECTION'):
                    for xmlSection in xmlChapter.iterfind('SECTION'):
                        scId = xmlSection.attrib['id']
                        self._read_section(xmlSection, scId)
                        if self.novel.sections[scId].scType < self.novel.chapters[chId].chType:
                            self.novel.sections[scId].scType = self.novel.chapters[chId].chType
                        self.novel.tree.append(chId, scId)
        except TypeError:
            pass

    def _read_characters(self, root):
        try:
            for xmlCharacter in root.find('CHARACTERS'):
                crId = xmlCharacter.attrib['id']
                self.novel.characters[crId] = Character(on_element_change=self.on_element_change)
                self.novel.characters[crId].isMajor = xmlCharacter.get('major', None) == '1'
                self.novel.characters[crId].title = get_element_text(xmlCharacter, 'Title')
                self.novel.characters[crId].links = self._get_link_dict(xmlCharacter)
                self.novel.characters[crId].desc = xml_element_to_text(xmlCharacter.find('Desc'))
                self.novel.characters[crId].aka = get_element_text(xmlCharacter, 'Aka')
                tags = string_to_list(get_element_text(xmlCharacter, 'Tags'))
                self.novel.characters[crId].tags = self._strip_spaces(tags)
                self.novel.characters[crId].notes = xml_element_to_text(xmlCharacter.find('Notes'))
                self.novel.characters[crId].bio = xml_element_to_text(xmlCharacter.find('Bio'))
                self.novel.characters[crId].goals = xml_element_to_text(xmlCharacter.find('Goals'))
                self.novel.characters[crId].fullName = get_element_text(xmlCharacter, 'FullName')
                self.novel.characters[crId].birthDate = get_element_text(xmlCharacter, 'BirthDate')
                self.novel.characters[crId].deathDate = get_element_text(xmlCharacter, 'DeathDate')
                self.novel.tree.append(CR_ROOT, crId)
        except TypeError:
            pass

    def _read_items(self, root):
        try:
            for xmlItem in root.find('ITEMS'):
                itId = xmlItem.attrib['id']
                self.novel.items[itId] = WorldElement(on_element_change=self.on_element_change)
                self.novel.items[itId].title = get_element_text(xmlItem, 'Title')
                self.novel.items[itId].desc = xml_element_to_text(xmlItem.find('Desc'))
                self.novel.items[itId].aka = get_element_text(xmlItem, 'Aka')
                tags = string_to_list(get_element_text(xmlItem, 'Tags'))
                self.novel.items[itId].tags = self._strip_spaces(tags)
                self.novel.items[itId].links = self._get_link_dict(xmlItem)
                self.novel.tree.append(IT_ROOT, itId)
        except TypeError:
            pass

    def _read_locations(self, root):
        try:
            for xmlLocation in root.find('LOCATIONS'):
                lcId = xmlLocation.attrib['id']
                self.novel.locations[lcId] = WorldElement(on_element_change=self.on_element_change)
                self.novel.locations[lcId].title = get_element_text(xmlLocation, 'Title')
                self.novel.locations[lcId].links = self._get_link_dict(xmlLocation)
                self.novel.locations[lcId].desc = xml_element_to_text(xmlLocation.find('Desc'))
                self.novel.locations[lcId].aka = get_element_text(xmlLocation, 'Aka')
                tags = string_to_list(get_element_text(xmlLocation, 'Tags'))
                self.novel.locations[lcId].tags = self._strip_spaces(tags)
                self.novel.tree.append(LC_ROOT, lcId)
        except TypeError:
            pass

    def _read_project(self, root):
        xmlProject = root.find('PROJECT')
        self.novel.renumberChapters = xmlProject.get('renumberChapters', None) == '1'
        self.novel.renumberParts = xmlProject.get('renumberParts', None) == '1'
        self.novel.renumberWithinParts = xmlProject.get('renumberWithinParts', None) == '1'
        self.novel.romanChapterNumbers = xmlProject.get('romanChapterNumbers', None) == '1'
        self.novel.romanPartNumbers = xmlProject.get('romanPartNumbers', None) == '1'
        self.novel.saveWordCount = xmlProject.get('saveWordCount', None) == '1'
        workPhase = xmlProject.get('workPhase', None)
        if workPhase in ('1', '2', '3', '4', '5'):
            self.novel.workPhase = int(workPhase)
        else:
            self.novel.workPhase = None
        self.novel.title = get_element_text(xmlProject, 'Title')
        self.novel.authorName = get_element_text(xmlProject, 'Author')
        self.novel.desc = xml_element_to_text(xmlProject.find('Desc'))
        self.novel.chapterHeadingPrefix = get_element_text(xmlProject, 'ChapterHeadingPrefix')
        self.novel.chapterHeadingSuffix = get_element_text(xmlProject, 'ChapterHeadingSuffix')
        self.novel.partHeadingPrefix = get_element_text(xmlProject, 'PartHeadingPrefix')
        self.novel.partHeadingSuffix = get_element_text(xmlProject, 'PartHeadingSuffix')
        self.novel.customGoal = get_element_text(xmlProject, 'CustomGoal')
        self.novel.customConflict = get_element_text(xmlProject, 'CustomConflict')
        self.novel.customOutcome = get_element_text(xmlProject, 'CustomOutcome')
        self.novel.customChrBio = get_element_text(xmlProject, 'CustomChrBio')
        self.novel.customChrGoals = get_element_text(xmlProject, 'CustomChrGoals')
        if xmlProject.find('WordCountStart') is not None:
            self.novel.wordCountStart = int(xmlProject.find('WordCountStart').text)
        if xmlProject.find('WordTarget') is not None:
            self.novel.wordTarget = int(xmlProject.find('WordTarget').text)
        self.novel.referenceDate = get_element_text(xmlProject, 'ReferenceDate')

    def _read_projectnotes(self, root):
        try:
            for xmlProjectnote in root.find('PROJECTNOTES'):
                pnId = xmlProjectnote.attrib['id']
                self.novel.projectNotes[pnId] = BasicElement()
                self.novel.projectNotes[pnId].title = get_element_text(xmlProjectnote, 'Title')
                self.novel.projectNotes[pnId].desc = xml_element_to_text(xmlProjectnote.find('Desc'))
                self.novel.tree.append(PN_ROOT, pnId)
        except TypeError:
            pass

    def _read_section(self, xmlSection, scId):
        self.novel.sections[scId] = Section(on_element_change=self.on_element_change)
        typeStr = xmlSection.get('type', '0')
        if typeStr in ('0', '1', '2', '3'):
            self.novel.sections[scId].scType = int(typeStr)
        else:
            self.novel.sections[scId].scType = 1
        status = xmlSection.get('status', None)
        if status in ('2', '3', '4', '5'):
            self.novel.sections[scId].status = int(status)
        else:
            self.novel.sections[scId].status = 1
        scPacing = xmlSection.get('pacing', 0)
        if scPacing in ('1', '2'):
            self.novel.sections[scId].scPacing = int(scPacing)
        else:
            self.novel.sections[scId].scPacing = 0
        self.novel.sections[scId].appendToPrev = xmlSection.get('append', None) == '1'
        self.novel.sections[scId].title = get_element_text(xmlSection, 'Title')
        self.novel.sections[scId].desc = xml_element_to_text(xmlSection.find('Desc'))

        if xmlSection.find('Content'):
            xmlStr = ET.tostring(xmlSection.find('Content'),
                                 encoding='utf-8',
                                 short_empty_elements=False
                                 ).decode('utf-8')
            xmlStr = xmlStr.replace('<Content>', '').replace('</Content>', '')

            lines = xmlStr.split('\n')
            newlines = []
            for line in lines:
                newlines.append(line.strip())
            xmlStr = ''.join(newlines)
            if xmlStr:
                self.novel.sections[scId].sectionContent = xmlStr
            else:
                self.novel.sections[scId].sectionContent = '<p></p>'
        else:
            self.novel.sections[scId].sectionContent = '<p></p>'

        self.novel.sections[scId].notes = xml_element_to_text(xmlSection.find('Notes'))

        tags = string_to_list(get_element_text(xmlSection, 'Tags'))
        self.novel.sections[scId].tags = self._strip_spaces(tags)

        if xmlSection.find('Date') is not None:
            dateStr = xmlSection.find('Date').text
            try:
                date.fromisoformat(dateStr)
            except:
                self.novel.sections[scId].date = None
            else:
                self.novel.sections[scId].date = dateStr
        elif xmlSection.find('Day') is not None:
            dayStr = xmlSection.find('Day').text
            try:
                int(dayStr)
            except ValueError:
                self.novel.sections[scId].day = None
            else:
                self.novel.sections[scId].day = dayStr

        if xmlSection.find('Time') is not None:
            timeStr = xmlSection.find('Time').text
            try:
                time.fromisoformat(timeStr)
            except:
                self.novel.sections[scId].time = None
            else:
                self.novel.sections[scId].time = timeStr

        self.novel.sections[scId].lastsDays = get_element_text(xmlSection, 'LastsDays')
        self.novel.sections[scId].lastsHours = get_element_text(xmlSection, 'LastsHours')
        self.novel.sections[scId].lastsMinutes = get_element_text(xmlSection, 'LastsMinutes')
        self.novel.sections[scId].goal = xml_element_to_text(xmlSection.find('Goal'))
        self.novel.sections[scId].conflict = xml_element_to_text(xmlSection.find('Conflict'))
        self.novel.sections[scId].outcome = xml_element_to_text(xmlSection.find('Outcome'))

        scCharacters = []
        xmlCharacters = xmlSection.find('Characters')
        if xmlCharacters is not None:
            crIds = xmlCharacters.get('ids', None)
            for crId in string_to_list(crIds, divider=' '):
                if crId and crId in self.novel.characters:
                    scCharacters.append(crId)
        self.novel.sections[scId].characters = scCharacters

        scLocations = []
        xmlLocations = xmlSection.find('Locations')
        if xmlLocations is not None:
            lcIds = xmlLocations.get('ids', None)
            for lcId in string_to_list(lcIds, divider=' '):
                if lcId and lcId in self.novel.locations:
                    scLocations.append(lcId)
        self.novel.sections[scId].locations = scLocations

        scItems = []
        xmlItems = xmlSection.find('Items')
        if xmlItems is not None:
            itIds = xmlItems.get('ids', None)
            for itId in string_to_list(itIds, divider=' '):
                if itId and itId in self.novel.items:
                    scItems.append(itId)
        self.novel.sections[scId].items = scItems

    def _strip_spaces(self, lines):
        stripped = []
        for line in lines:
            stripped.append(line.strip())
        return stripped

    def _write_element_tree(self, xmlProject):
        backedUp = False
        if os.path.isfile(xmlProject.filePath):
            try:
                os.replace(xmlProject.filePath, f'{xmlProject.filePath}.bak')
            except:
                raise Error(f'{_("Cannot overwrite file")}: "{norm_path(xmlProject.filePath)}".')
            else:
                backedUp = True
        try:
            xmlProject.xmlTree.write(xmlProject.filePath, xml_declaration=False, encoding='utf-8')
        except Error:
            if backedUp:
                os.replace(f'{xmlProject.filePath}.bak', xmlProject.filePath)
            raise Error(f'{_("Cannot write file")}: "{norm_path(xmlProject.filePath)}".')

from datetime import datetime
from datetime import timedelta



def create_id(elements, prefix=''):
    i = 1
    while f'{prefix}{i}' in elements:
        i += 1
    return f'{prefix}{i}'

import codecs
from json import JSONDecodeError
import json
import zipfile



def open_timeline(filePath):
    try:
        with zipfile.ZipFile(filePath, 'r') as myzip:
            jsonBytes = myzip.read('timeline.json')
            jsonStr = codecs.decode(jsonBytes, encoding='utf-8')
    except:
        raise Error(f'{_("Cannot read timeline data")}.')
    if not jsonStr:
        raise Error(f'{_("No JSON part found in timeline data")}.')
    try:
        jsonData = json.loads(jsonStr)
    except JSONDecodeError:
        raise Error(f'{_("Invalid JSON data in timeline")}.')
    return jsonData


def save_timeline(jsonData, filePath):
    backedUp = False
    if os.path.isfile(filePath):
        try:
            os.replace(filePath, f'{filePath}.bak')
        except:
            raise Error(f'{_("Cannot overwrite file")}: "{norm_path(filePath)}".')
        else:
            backedUp = True
    try:
        with zipfile.ZipFile(filePath, 'w', compression=zipfile.ZIP_DEFLATED) as f:
            f.writestr('timeline.json', json.dumps(jsonData))
    except:
        if backedUp:
            os.replace(f'{filePath}.bak', filePath)
        raise Error(f'{_("Cannot write file")}: "{norm_path(filePath)}".')

import math


def get_moon_phase(dateStr):
    try:
        y, m, d = dateStr.split('-')
        year = int(y)
        month = int(m)
        day = int(d)
        r = year % 100
        r %= 19
        if r > 9:
            r -= 19
        r = ((r * 11) % 30) + month + day
        if month < 3:
            r += 2
        if year < 2000:
            r -= 4
        else:
            r -= 8.3
        r = math.floor(r + 0.5) % 30
        if r < 0:
            r += 30
    except:
        r = None
    return r


def get_moon_phase_plus(dateStr):
    s = '  ))))))))))))OOO(((((((((((( '
    p = '00¼¼¼¼½½½½¾¾¾¾111¾¾¾¾½½½½¼¼¼¼0'
    r = get_moon_phase(dateStr)
    if r is not None:
        result = f'{r} [  {s[r]}  ] {p[r]}'
    else:
        result = ''
    return result


from hashlib import pbkdf2_hmac

guidChars = list('ABCDEF0123456789')


def get_sub_guid(key, size):
    keyInt = int.from_bytes(key, byteorder='big')
    guid = ''
    while len(guid) < size and keyInt > 0:
        guid += guidChars[keyInt % len(guidChars)]
        keyInt //= len(guidChars)
    return guid


def get_uid(text):
    text = text.encode('utf-8')
    sizes = [8, 4, 4, 4, 12]
    salts = [b'a', b'b', b'c', b'd', b'e']
    guid = []
    for i in range(5):
        key = pbkdf2_hmac('sha1', text, salts[i], 1)
        guid.append(get_sub_guid(key, sizes[i]))
    return '-'.join(guid)


class JsonTimeline2(File):
    EXTENSION = '.aeonzip'
    DESCRIPTION = _('Aeon Timeline 2 project')
    SUFFIX = ''
    VALUE_YES = '1'
    DATE_LIMIT = (datetime(1, 1, 1) - datetime.min).total_seconds()
    PROPERTY_MOONPHASE = 'Moon phase'

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath, **kwargs)
        self._jsonData = None

        self._entityNarrative = kwargs['narrative_arc']

        self._propertyDesc = kwargs['property_description']
        self._propertyNotes = kwargs['property_notes']

        self._roleLocation = kwargs['role_location']
        self._roleItem = kwargs['role_item']
        self._roleCharacter = kwargs['role_character']

        self._typeCharacter = kwargs['type_character']
        self._typeLocation = kwargs['type_location']
        self._typeItem = kwargs['type_item']

        self._tplDateGuid = None
        self._typeArcGuid = None
        self._typeCharacterGuid = None
        self._typeLocationGuid = None
        self._typeItemGuid = None
        self._roleArcGuid = None
        self._roleStorylineGuid = None
        self._roleCharacterGuid = None
        self._roleLocationGuid = None
        self._roleItemGuid = None
        self._entityNarrativeGuid = None
        self._propertyDescGuid = None
        self._propertyNotesGuid = None
        self._propertyMoonphaseGuid = None

        self.referenceDate = None
        self._addMoonphase = kwargs['add_moonphase']
        self._sectionColor = kwargs['color_section']
        self._eventColor = kwargs['color_event']
        self._pointColor = kwargs['color_point']
        self._timestampMax = 0
        self._displayIdMax = 0.0
        self._colors = {}
        self._arcCount = 0
        self._characterGuidsById = {}
        self._locationGuidsById = {}
        self._itemGuidsById = {}
        self._arcGuidsById = {}
        self._trashEvents = []

    def read(self):
        self.referenceDate = datetime.today()
        if self.novel.referenceDate:
            defaultDateTime = f'{self.novel.referenceDate} 00:00:00'
            try:
                self.referenceDate = datetime.fromisoformat(defaultDateTime)
            except ValueError:
                pass

        self._jsonData = open_timeline(self.filePath)

        for tplCol in self._jsonData['template']['colors']:
            self._colors[tplCol['name']] = tplCol['guid']

        for tplRgp in self._jsonData['template']['rangeProperties']:
            if tplRgp['type'] == 'date':
                for tplRgpCalEra in tplRgp['calendar']['eras']:
                    if tplRgpCalEra['name'] == 'AD':
                        self._tplDateGuid = tplRgp['guid']
                        break

        if self._tplDateGuid is None:
            raise Error(_('"AD" era is missing in the calendar.'))

        for tplTyp in self._jsonData['template']['types']:
            if tplTyp['name'] == 'Arc':
                self._typeArcGuid = tplTyp['guid']
                for tplTypRol in tplTyp['roles']:
                    if tplTypRol['name'] == 'Arc':
                        self._roleArcGuid = tplTypRol['guid']
                    elif tplTypRol['name'] == 'Storyline':
                        self._roleStorylineGuid = tplTypRol['guid']
            elif tplTyp['name'] == self._typeCharacter:
                self._typeCharacterGuid = tplTyp['guid']
                for tplTypRol in tplTyp['roles']:
                    if tplTypRol['name'] == self._roleCharacter:
                        self._roleCharacterGuid = tplTypRol['guid']
            elif tplTyp['name'] == self._typeLocation:
                self._typeLocationGuid = tplTyp['guid']
                for tplTypRol in tplTyp['roles']:
                    if tplTypRol['name'] == self._roleLocation:
                        self._roleLocationGuid = tplTypRol['guid']
                        break

            elif tplTyp['name'] == self._typeItem:
                self._typeItemGuid = tplTyp['guid']
                for tplTypRol in tplTyp['roles']:
                    if tplTypRol['name'] == self._roleItem:
                        self._roleItemGuid = tplTypRol['guid']
                        break

        if self._typeArcGuid is None:
            self._typeArcGuid = get_uid('typeArcGuid')
            typeCount = len(self._jsonData['template']['types'])
            self._jsonData['template']['types'].append(
                {
                'color': 'iconYellow',
                'guid': self._typeArcGuid,
                'icon': 'book',
                'name': 'Arc',
                'persistent': True,
                'roles': [],
                'sortOrder': typeCount
                })
        for entityType in self._jsonData['template']['types']:
            if entityType['name'] == 'Arc':
                if self._roleArcGuid is None:
                    self._roleArcGuid = get_uid('_roleArcGuid')
                    entityType['roles'].append(
                        {
                        'allowsMultipleForEntity': True,
                        'allowsMultipleForEvent': True,
                        'allowsPercentAllocated': False,
                        'guid': self._roleArcGuid,
                        'icon': 'circle text',
                        'mandatoryForEntity': False,
                        'mandatoryForEvent': False,
                        'name': 'Arc',
                        'sortOrder': 0
                        })
                if self._roleStorylineGuid is None:
                    self._roleStorylineGuid = get_uid('_roleStorylineGuid')
                    entityType['roles'].append(
                        {
                        'allowsMultipleForEntity': True,
                        'allowsMultipleForEvent': True,
                        'allowsPercentAllocated': False,
                        'guid': self._roleStorylineGuid,
                        'icon': 'circle filled text',
                        'mandatoryForEntity': False,
                        'mandatoryForEvent': False,
                        'name': 'Storyline',
                        'sortOrder': 0
                        })

        if self._typeCharacterGuid is None:
            self._typeCharacterGuid = get_uid('_typeCharacterGuid')
            self._roleCharacterGuid = get_uid('_roleCharacterGuid')
            typeCount = len(self._jsonData['template']['types'])
            self._jsonData['template']['types'].append(
                {
                'color': 'iconRed',
                'guid': self._typeCharacterGuid,
                'icon': 'person',
                'name': self._typeCharacter,
                'persistent': False,
                'roles': [
                    {
                    'allowsMultipleForEntity': True,
                    'allowsMultipleForEvent': True,
                    'allowsPercentAllocated': False,
                    'guid': self._roleCharacterGuid,
                    'icon': 'circle text',
                    'mandatoryForEntity': False,
                    'mandatoryForEvent': False,
                    'name': self._roleCharacter,
                    'sortOrder': 0
                    }
                ],
                'sortOrder': typeCount
                })

        if self._typeLocationGuid is None:
            self._typeLocationGuid = get_uid('_typeLocationGuid')
            self._roleLocationGuid = get_uid('_roleLocationGuid')
            typeCount = len(self._jsonData['template']['types'])
            self._jsonData['template']['types'].append(
                {
                'color': 'iconOrange',
                'guid': self._typeLocationGuid,
                'icon': 'map',
                'name': self._typeLocation,
                'persistent': True,
                'roles': [
                    {
                    'allowsMultipleForEntity': True,
                    'allowsMultipleForEvent': True,
                    'allowsPercentAllocated': False,
                    'guid': self._roleLocationGuid,
                    'icon': 'circle text',
                    'mandatoryForEntity': False,
                    'mandatoryForEvent': False,
                    'name': self._roleLocation,
                    'sortOrder': 0
                    }
                ],
                'sortOrder': typeCount
                })

        if self._typeItemGuid is None:
            self._typeItemGuid = get_uid('_typeItemGuid')
            self._roleItemGuid = get_uid('_roleItemGuid')
            typeCount = len(self._jsonData['template']['types'])
            self._jsonData['template']['types'].append(
                {
                'color': 'iconPurple',
                'guid': self._typeItemGuid,
                'icon': 'cube',
                'name': self._typeItem,
                'persistent': True,
                'roles': [
                    {
                    'allowsMultipleForEntity': True,
                    'allowsMultipleForEvent': True,
                    'allowsPercentAllocated': False,
                    'guid': self._roleItemGuid,
                    'icon': 'circle text',
                    'mandatoryForEntity': False,
                    'mandatoryForEvent': False,
                    'name': self._roleItem,
                    'sortOrder': 0
                    }
                    ],
                'sortOrder': typeCount
                })


        targetScIdsByTitle = {}
        for scId in self.novel.sections:
            title = self.novel.sections[scId].title
            if title:
                if title in targetScIdsByTitle:
                    raise Error(_('Ambiguous noveltree section title "{}".').format(title))

                targetScIdsByTitle[title] = scId

        targetCrIdsByTitle = {}
        for crId in self.novel.characters:
            title = self.novel.characters[crId].title
            if title:
                if title in targetCrIdsByTitle:
                    raise Error(_('Ambiguous noveltree character "{}".').format(title))

                targetCrIdsByTitle[title] = crId

        targetLcIdsByTitle = {}
        for lcId in self.novel.locations:
            title = self.novel.locations[lcId].title
            if title:
                if title in targetLcIdsByTitle:
                    raise Error(_('Ambiguous noveltree location "{}".').format(title))

                targetLcIdsByTitle[title] = lcId

        targetItIdsByTitle = {}
        for itId in self.novel.items:
            title = self.novel.items[itId].title
            if title:
                if title in targetItIdsByTitle:
                    raise Error(_('Ambiguous noveltree item "{}".').format(title))

                targetItIdsByTitle[title] = itId

        targetAcIdsByTitle = {}
        for acId in self.novel.arcs:
            title = self.novel.arcs[acId].title
            if title:
                if title in targetAcIdsByTitle:
                    raise Error(_('Ambiguous noveltree arc "{}".').format(title))

                targetAcIdsByTitle[title] = acId

        crIdsByGuid = {}
        lcIdsByGuid = {}
        itIdsByGuid = {}
        acIdsByGuid = {}

        characterNames = []
        locationNames = []
        itemNames = []
        arcNames = []

        for entity in self._jsonData['entities']:
            if entity['entityType'] == self._typeCharacterGuid:

                if entity['name'] in characterNames:
                    raise Error(_('Ambiguous Aeon character "{}".').format(entity['name']))

                characterNames.append(entity['name'])

                if entity['name'] in targetCrIdsByTitle:
                    crId = targetCrIdsByTitle[entity['name']]
                else:
                    crId = create_id(self.novel.characters, prefix=CHARACTER_PREFIX)
                    self.novel.characters[crId] = Character()
                    self.novel.characters[crId].title = entity['name']
                    self.novel.tree.append(CR_ROOT, crId)
                crIdsByGuid[entity['guid']] = crId
                self._characterGuidsById[crId] = entity['guid']
                if entity['notes']:
                    self.novel.characters[crId].notes = entity['notes']
                else:
                    entity['notes'] = ''
                createRangePosition = entity.get('createRangePosition', None)
                if createRangePosition:
                    timestamp = createRangePosition['timestamp']
                    if timestamp >= self.DATE_LIMIT:
                        birthDate = datetime.min + timedelta(seconds=timestamp)
                        self.novel.characters[crId].birthDate = birthDate.isoformat().split('T')[0]
                destroyRangePosition = entity.get('destroyRangePosition', None)
                if destroyRangePosition:
                    timestamp = destroyRangePosition['timestamp']
                    if timestamp >= self.DATE_LIMIT:
                        deathDate = datetime.min + timedelta(seconds=timestamp)
                        self.novel.characters[crId].deathDate = deathDate.isoformat().split('T')[0]

            elif entity['entityType'] == self._typeLocationGuid:

                if entity['name'] in locationNames:
                    raise Error(_('Ambiguous Aeon location "{}".').format(entity['name']))

                locationNames.append(entity['name'])

                if entity['name'] in targetLcIdsByTitle:
                    lcId = targetLcIdsByTitle[entity['name']]
                else:
                    lcId = create_id(self.novel.locations, prefix=LOCATION_PREFIX)
                    self.novel.locations[lcId] = WorldElement()
                    self.novel.locations[lcId].title = entity['name']
                    self.novel.tree.append(LC_ROOT, lcId)
                lcIdsByGuid[entity['guid']] = lcId
                self._locationGuidsById[lcId] = entity['guid']

            elif entity['entityType'] == self._typeItemGuid:

                if entity['name'] in itemNames:
                    raise Error(_('Ambiguous Aeon item "{}".').format(entity['name']))

                itemNames.append(entity['name'])

                if entity['name'] in targetItIdsByTitle:
                    itId = targetItIdsByTitle[entity['name']]
                else:
                    itId = create_id(self.novel.items, prefix=ITEM_PREFIX)
                    self.novel.items[itId] = WorldElement()
                    self.novel.items[itId].title = entity['name']
                    self.novel.tree.append(IT_ROOT, itId)
                itIdsByGuid[entity['guid']] = itId
                self._itemGuidsById[itId] = entity['guid']

            elif entity['entityType'] == self._typeArcGuid:

                if entity['name'] in arcNames:
                    raise Error(_('Ambiguous Aeon arc "{}".').format(entity['name']))

                arcNames.append(entity['name'])

                if entity['name'] in targetAcIdsByTitle:
                    acId = targetAcIdsByTitle[entity['name']]
                elif entity['name'] != self._entityNarrative:

                    acId = create_id(self.novel.arcs, prefix=ARC_PREFIX)
                    self.novel.arcs[acId] = Arc()
                    self.novel.arcs[acId].title = entity['name']
                    self.novel.arcs[acId].shortName = entity['name']
                    self.novel.tree.append(AC_ROOT, acId)
                if entity['name'] == self._entityNarrative:
                    self._entityNarrativeGuid = entity['guid']
                else:
                    acIdsByGuid[entity['guid']] = acId
                    self._arcGuidsById[acId] = entity['guid']
                    self._arcCount += 1

        hasPropertyNotes = False
        hasPropertyDesc = False
        for tplPrp in self._jsonData['template']['properties']:
            if tplPrp['name'] == self._propertyDesc:
                self._propertyDescGuid = tplPrp['guid']
                hasPropertyDesc = True
            elif tplPrp['name'] == self._propertyNotes:
                self._propertyNotesGuid = tplPrp['guid']
                hasPropertyNotes = True
            elif tplPrp['name'] == self.PROPERTY_MOONPHASE:
                self._propertyMoonphaseGuid = tplPrp['guid']

        if not hasPropertyNotes:
            for tplPrp in self._jsonData['template']['properties']:
                tplPrp['sortOrder'] += 1
            self._propertyNotesGuid = get_uid('_propertyNotesGuid')
            self._jsonData['template']['properties'].insert(0, {
                'calcMode': 'default',
                'calculate': False,
                'fadeEvents': False,
                'guid': self._propertyNotesGuid,
                'icon': 'tag',
                'isMandatory': False,
                'name': self._propertyNotes,
                'sortOrder': 0,
                'type': 'multitext'
                })
        if not hasPropertyDesc:
            n = len(self._jsonData['template']['properties'])
            self._propertyDescGuid = get_uid('_propertyDescGuid')
            self._jsonData['template']['properties'].append({
                'calcMode': 'default',
                'calculate': False,
                'fadeEvents': False,
                'guid': self._propertyDescGuid,
                'icon': 'tag',
                'isMandatory': False,
                'name': self._propertyDesc,
                'sortOrder': n,
                'type': 'multitext'
                })
        if self._addMoonphase and self._propertyMoonphaseGuid is None:
            n = len(self._jsonData['template']['properties'])
            self._propertyMoonphaseGuid = get_uid('_propertyMoonphaseGuid')
            self._jsonData['template']['properties'].append({
                'calcMode': 'default',
                'calculate': False,
                'fadeEvents': False,
                'guid': self._propertyMoonphaseGuid,
                'icon': 'flag',
                'isMandatory': False,
                'name': self.PROPERTY_MOONPHASE,
                'sortOrder': n,
                'type': 'text'
                })

        if not self._entityNarrativeGuid:
            return

        scIdsByDate = {}
        scnTitles = []
        narrativeEvents = []
        for event in self._jsonData['events']:

            isNarrative = False
            for evtRel in event['relationships']:
                if evtRel['role'] == self._roleArcGuid:
                    if evtRel['entity'] == self._entityNarrativeGuid:
                        isNarrative = True
                        break

            eventTitle = event['title'].strip()
            if eventTitle in scnTitles:
                raise Error(f'Ambiguous Aeon event title "{event["title"]}".')

            scnTitles.append(eventTitle)

            if eventTitle in targetScIdsByTitle:
                scId = targetScIdsByTitle[eventTitle]
            elif isNarrative:
                scId = create_id(self.novel.sections, prefix=SECTION_PREFIX)
                self.novel.sections[scId] = Section(
                    title=eventTitle,
                    status=1,
                    scType=0,
                    scPacing=0,
                    )
            else:
                continue

            narrativeEvents.append(scId)
            displayId = float(event['displayId'])
            if displayId > self._displayIdMax:
                self._displayIdMax = displayId

            hasDescription = False
            hasNotes = False
            for evtVal in event['values']:

                if evtVal['property'] == self._propertyDescGuid:
                    hasDescription = True
                    if evtVal['value']:
                        self.novel.sections[scId].desc = evtVal['value']

                elif evtVal['property'] == self._propertyNotesGuid:
                    hasNotes = True
                    if evtVal['value']:
                        self.novel.sections[scId].notes = evtVal['value']

            if not hasDescription:
                event['values'].append({'property': self._propertyDescGuid, 'value': ''})
            if not hasNotes:
                event['values'].append({'property': self._propertyNotesGuid, 'value': ''})

            if event['tags']:
                self.novel.sections[scId].tags = []
                for evtTag in event['tags']:
                    self.novel.sections[scId].tags.append(evtTag)

            timestamp = 0
            for evtRgv in event['rangeValues']:
                if evtRgv['rangeProperty'] == self._tplDateGuid:
                    timestamp = evtRgv['position']['timestamp']
                    if timestamp >= self.DATE_LIMIT:
                        sectionStart = datetime.min + timedelta(seconds=timestamp)
                        startDateTime = sectionStart.isoformat().split('T')

                        if self.novel.sections[scId].day is not None:
                            sectionDelta = sectionStart - self.referenceDate
                            self.novel.sections[scId].day = str(sectionDelta.days)
                        elif (self.novel.sections[scId].time is not None) and (self.novel.sections[scId].date is None):
                            self.novel.sections[scId].day = '0'
                        else:
                            self.novel.sections[scId].date = startDateTime[0]
                        self.novel.sections[scId].time = startDateTime[1]

                        if 'years' in evtRgv['span'] or 'months' in evtRgv['span']:
                            endYear = sectionStart.year
                            endMonth = sectionStart.month
                            if 'years' in evtRgv['span']:
                                endYear += evtRgv['span']['years']
                            if 'months' in evtRgv['span']:
                                endMonth += evtRgv['span']['months']
                                while endMonth > 12:
                                    endMonth -= 12
                                    endYear += 1
                            sectionEnd = datetime(endYear, endMonth, sectionStart.day)
                            sectionDuration = sectionEnd - datetime(sectionStart.year, sectionStart.month, sectionStart.day)
                            lastsDays = sectionDuration.days
                            lastsHours = sectionDuration.seconds // 3600
                            lastsMinutes = (sectionDuration.seconds % 3600) // 60
                        else:
                            lastsDays = 0
                            lastsHours = 0
                            lastsMinutes = 0
                        if 'weeks' in evtRgv['span']:
                            lastsDays += evtRgv['span']['weeks'] * 7
                        if 'days' in evtRgv['span']:
                            lastsDays += evtRgv['span']['days']
                        if 'hours' in evtRgv['span']:
                            lastsDays += evtRgv['span']['hours'] // 24
                            lastsHours += evtRgv['span']['hours'] % 24
                        if 'minutes' in evtRgv['span']:
                            lastsHours += evtRgv['span']['minutes'] // 60
                            lastsMinutes += evtRgv['span']['minutes'] % 60
                        if 'seconds' in evtRgv['span']:
                            lastsMinutes += evtRgv['span']['seconds'] // 60
                        lastsHours += lastsMinutes // 60
                        lastsMinutes %= 60
                        lastsDays += lastsHours // 24
                        lastsHours %= 24
                        self.novel.sections[scId].lastsDays = str(lastsDays)
                        self.novel.sections[scId].lastsHours = str(lastsHours)
                        self.novel.sections[scId].lastsMinutes = str(lastsMinutes)
                    break

            if not timestamp in scIdsByDate:
                scIdsByDate[timestamp] = []
            scIdsByDate[timestamp].append(scId)

            self.novel.sections[scId].scType = 1
            scCharacters = []
            scLocations = []
            scItems = []
            for evtRel in event['relationships']:

                if evtRel['role'] == self._roleArcGuid:
                    if evtRel['entity'] == self._entityNarrativeGuid:
                        self.novel.sections[scId].scType = 0
                        if timestamp > self._timestampMax:
                            self._timestampMax = timestamp

                elif evtRel['role'] == self._roleCharacterGuid:
                    crId = crIdsByGuid[evtRel['entity']]
                    scCharacters.append(crId)

                elif evtRel['role'] == self._roleLocationGuid:
                    lcId = lcIdsByGuid[evtRel['entity']]
                    scLocations.append(lcId)

                elif evtRel['role'] == self._roleItemGuid:
                    itId = itIdsByGuid[evtRel['entity']]
                    scItems.append(itId)

                elif evtRel['role'] == self._roleStorylineGuid:
                    acId = acIdsByGuid[evtRel['entity']]
                    self.novel.sections[scId].scArcs.append(acId)

                    acSections = self.novel.arcs[acId].sections
                    if acSections is None:
                        acSections = []
                    acSections.append(scId)
                    self.novel.arcs[acId].sections = acSections

            if scCharacters:
                self.novel.sections[scId].characters = scCharacters
            if scLocations:
                self.novel.sections[scId].locations = scLocations
            if scItems:
                self.novel.sections[scId].items = scItems

        for scId in self.novel.sections:
            if not scId in narrativeEvents:
                if self.novel.sections[scId].scType == 0:
                    self.novel.sections[scId].scType = 1

        sectionsInChapters = []
        for chId in self.novel.tree.get_children(CH_ROOT):
            sectionsInChapters.extend(self.novel.tree.get_children(chId))

        newChapterId = create_id(self.novel.chapters, prefix=CHAPTER_PREFIX)
        newChapter = Chapter()
        newChapter.title = _('New sections')
        newChapter.chType = 0

        srtSections = sorted(scIdsByDate.items())
        for __, scList in srtSections:
            for scId in scList:
                if not scId in sectionsInChapters:
                    if not newChapterId in self.novel.tree.get_children(CH_ROOT):
                        self.novel.chapters[newChapterId] = newChapter
                        self.novel.tree.append(CH_ROOT, newChapterId)
                    self.novel.tree.append(newChapterId, scId)

        if self._timestampMax == 0:
            self._timestampMax = (self.referenceDate - datetime.min).total_seconds()

    def write(self, source):

        def get_timestamp(section):
            self._timestampMax += 1
            timestamp = int(self._timestampMax)
            try:
                if section.date:
                    isoDt = section.date
                    if section.time:
                        isoDt = (f'{isoDt} {section.time}')
                timestamp = int((datetime.fromisoformat(isoDt) - datetime.min).total_seconds())
            except:
                pass
            return timestamp

        def get_span(section):
            span = {}
            if section.lastsDays:
                span['days'] = int(section.lastsDays)
            if section.lastsHours:
                span['hours'] = int(section.lastsHours)
            if section.lastsMinutes:
                span['minutes'] = int(section.lastsMinutes)
            return span

        def get_display_id():
            self._displayIdMax += 1
            return str(int(self._displayIdMax))

        def build_event(section):
            event = {
                'attachments': [],
                'color': '',
                'displayId': get_display_id(),
                'guid': get_uid(f'section{section.title}'),
                'links': [],
                'locked': False,
                'priority': 500,
                'rangeValues': [{
                    'minimumZoom':-1,
                    'position': {
                        'precision': 'minute',
                        'timestamp': self.DATE_LIMIT
                        },
                    'rangeProperty': self._tplDateGuid,
                    'span': {},
                    }],
                'relationships': [],
                'tags': [],
                'title': section.title,
                'values': [{
                    'property': self._propertyNotesGuid,
                    'value': ''
                    },
                    {
                    'property': self._propertyDescGuid,
                    'value': ''
                    }],
                }
            if section.scType == 0:
                event['color'] = self._colors[self._sectionColor]
            else:
                event['color'] = self._colors[self._eventColor]
            return event

        def get_character_date(isoDate):
            charaDate = datetime.fromisoformat(isoDate)
            timestamp = int((charaDate - datetime.min).total_seconds())
            return {
                "precision": "day",
                "rangePropertyGuid": self._tplDateGuid,
                "timestamp": timestamp
                }

        self.referenceDate = datetime.today()
        if source.referenceDate:
            defaultDateTime = f'{source.referenceDate} 00:00:00'
            try:
                self.referenceDate = datetime.fromisoformat(defaultDateTime)
            except ValueError:
                pass

        targetEvents = []
        for jEvent in self._jsonData['events']:
            targetEvents.append(jEvent['title'])

        linkedCharacters = []
        linkedLocations = []
        linkedItems = []
        linkedArcs = []

        srcScnTitles = []
        for chId in source.chapters:
            if source.chapters[chId].isTrash:
                continue

            for scId in source.tree.get_children(chId):
                if source.sections[scId].title in srcScnTitles:
                    raise Error(_('Ambiguous noveltree section title "{}".').format(source.sections[scId].title))

                srcScnTitles.append(source.sections[scId].title)

                if source.sections[scId].characters:
                    linkedCharacters = list(set(linkedCharacters + source.sections[scId].characters))
                if source.sections[scId].locations:
                    linkedLocations = list(set(linkedLocations + source.sections[scId].locations))
                if source.sections[scId].items:
                    linkedItems = list(set(linkedItems + source.sections[scId].items))
                if source.sections[scId].scArcs:
                    linkedArcs = list(set(linkedArcs + source.sections[scId].scArcs))

        srcChrNames = []
        for crId in source.characters:
            if not crId in linkedCharacters:
                continue

            if source.characters[crId].title in srcChrNames:
                raise Error(_('Ambiguous noveltree character "{}".').format(source.characters[crId].title))

            srcChrNames.append(source.characters[crId].title)

        srcLocTitles = []
        for lcId in source.locations:
            if not lcId in linkedLocations:
                continue

            if source.locations[lcId].title in srcLocTitles:
                raise Error(_('Ambiguous noveltree location "{}".').format(source.locations[lcId].title))

            srcLocTitles.append(source.locations[lcId].title)

        srcItmTitles = []
        for itId in source.items:
            if not itId in linkedItems:
                continue

            if source.items[itId].title in srcItmTitles:
                raise Error(_('Ambiguous noveltree item "{}".').format(source.items[itId].title))

            srcItmTitles.append(source.items[itId].title)

        srcArcTitles = []
        for acId in source.arcs:
            if not acId in linkedArcs:
                continue

            if source.arcs[acId].title in srcArcTitles:
                raise Error(_('Ambiguous noveltree arc "{}".').format(source.arcs[acId].title))

            srcArcTitles.append(source.arcs[acId].title)

        scIdsByTitle = {}
        for scId in self.novel.sections:
            if self.novel.sections[scId].title in scIdsByTitle:
                raise Error(_('Ambiguous Aeon event title "{}".').format(self.novel.sections[scId].title))

            scIdsByTitle[self.novel.sections[scId].title] = scId

            if not self.novel.sections[scId].title in srcScnTitles:
                if not self.novel.sections[scId].scType == 1:
                    self._trashEvents.append(scId)

        crIdsByTitle = {}
        for crId in self.novel.characters:
            if self.novel.characters[crId].title in crIdsByTitle:
                raise Error(_('Ambiguous Aeon character "{}".').format(self.novel.characters[crId].title))

            crIdsByTitle[self.novel.characters[crId].title] = crId

        lcIdsByTitle = {}
        for lcId in self.novel.locations:
            if self.novel.locations[lcId].title in lcIdsByTitle:
                raise Error(_('Ambiguous Aeon location "{}".').format(self.novel.locations[lcId].title))

            lcIdsByTitle[self.novel.locations[lcId].title] = lcId

        itIdsByTitle = {}
        for itId in self.novel.items:
            if self.novel.items[itId].title in itIdsByTitle:
                raise Error(_('Ambiguous Aeon item "{}".').format(self.novel.items[itId].title))

            itIdsByTitle[self.novel.items[itId].title] = itId

        acIdsByTitle = {}
        for acId in self.novel.arcs:
            if self.novel.arcs[acId].title in acIdsByTitle:
                raise Error(_('Ambiguous Aeon arc "{}".').format(self.novel.arcs[acId].title))

            acIdsByTitle[self.novel.arcs[acId].title] = acId

        chrCount = len(self.novel.characters)
        crIdsBySrcId = {}
        srcIdsbyCrId = {}
        for srcCrId in source.characters:
            if source.characters[srcCrId].title in crIdsByTitle:
                crId = crIdsByTitle[source.characters[srcCrId].title]
                crIdsBySrcId[srcCrId] = crId
                srcIdsbyCrId[crId] = srcCrId
            elif srcCrId in linkedCharacters:
                crId = create_id(self.novel.characters, prefix=CHARACTER_PREFIX)
                crIdsBySrcId[srcCrId] = crId
                srcIdsbyCrId[crId] = srcCrId
                self.novel.characters[crId] = source.characters[srcCrId]
                newGuid = get_uid(f'{crId}{self.novel.characters[crId].title}')
                self._characterGuidsById[crId] = newGuid
                jsonCharacter = {}
                birthDate = self.novel.characters[crId].birthDate
                if birthDate:
                    jsonCharacter['createRangePosition'] = get_character_date(birthDate)
                deathDate = self.novel.characters[crId].deathDate
                if deathDate:
                    jsonCharacter['destroyRangePosition'] = get_character_date(deathDate)
                jsonCharacter['entityType'] = self._typeCharacterGuid
                jsonCharacter['guid'] = newGuid
                jsonCharacter['icon'] = 'person'
                jsonCharacter['name'] = self.novel.characters[crId].title
                jsonCharacter['notes'] = ''
                jsonCharacter['sortOrder'] = chrCount
                jsonCharacter['swatchColor'] = 'darkPink'
                self._jsonData['entities'].append(jsonCharacter)
                chrCount += 1

        for entity in self._jsonData['entities']:
            if not entity['entityType'] == self._typeCharacterGuid:
                continue

            if not entity['name'] in crIdsByTitle:
                continue

            crId = crIdsByTitle[entity['name']]
            srcCrId = srcIdsbyCrId[crId]
            birthDate = source.characters[srcCrId].birthDate
            if birthDate:
                entity['createRangePosition'] = get_character_date(birthDate)
            else:
                try:
                    del entity['createRangePosition']
                except KeyError:
                    pass
            deathDate = source.characters[srcCrId].deathDate
            if deathDate:
                entity['destroyRangePosition'] = get_character_date(deathDate)
            else:
                try:
                    del entity['destroyRangePosition']
                except KeyError:
                    pass

        locCount = len(self.novel.locations)
        lcIdsBySrcId = {}
        for srcLcId in source.locations:
            if source.locations[srcLcId].title in lcIdsByTitle:
                lcIdsBySrcId[srcLcId] = lcIdsByTitle[source.locations[srcLcId].title]
            elif srcLcId in linkedLocations:
                lcId = create_id(self.novel.locations, prefix=LOCATION_PREFIX)
                lcIdsBySrcId[srcLcId] = lcId
                self.novel.locations[lcId] = source.locations[srcLcId]
                newGuid = get_uid(f'{lcId}{self.novel.locations[lcId].title}')
                self._locationGuidsById[lcId] = newGuid
                self._jsonData['entities'].append(
                    {
                    'entityType': self._typeLocationGuid,
                    'guid': newGuid,
                    'icon': 'map',
                    'name': self.novel.locations[lcId].title,
                    'notes': '',
                    'sortOrder': locCount,
                    'swatchColor': 'orange'
                    })
                locCount += 1

        itmCount = len(self.novel.items)
        itIdsBySrcId = {}
        for srcItId in source.items:
            if source.items[srcItId].title in itIdsByTitle:
                itIdsBySrcId[srcItId] = itIdsByTitle[source.items[srcItId].title]
            elif srcItId in linkedItems:
                itId = create_id(self.novel.items, prefix=ITEM_PREFIX)
                itIdsBySrcId[srcItId] = itId
                self.novel.items[itId] = source.items[srcItId]
                newGuid = get_uid(f'{itId}{self.novel.items[itId].title}')
                self._itemGuidsById[itId] = newGuid
                self._jsonData['entities'].append(
                    {
                    'entityType': self._typeItemGuid,
                    'guid': newGuid,
                    'icon': 'cube',
                    'name': self.novel.items[itId].title,
                    'notes': '',
                    'sortOrder': itmCount,
                    'swatchColor': 'denim'
                    })
                itmCount += 1

        arcCount = len(self.novel.arcs)
        acIdsBySrcId = {}
        for srcAcId in source.arcs:
            if source.arcs[srcAcId].title in acIdsByTitle:
                acIdsBySrcId[srcAcId] = acIdsByTitle[source.arcs[srcAcId].title]
            elif srcAcId in linkedArcs:
                acId = create_id(self.novel.arcs, prefix=ARC_PREFIX)

                acIdsBySrcId[srcAcId] = acId
                self.novel.arcs[acId] = source.arcs[srcAcId]
                arcName = self.novel.arcs[acId].title
                newGuid = get_uid(f'{acId}{arcName}')
                self._arcGuidsById[acId] = newGuid
                self._jsonData['entities'].append(
                    {
                    'entityType': self._typeArcGuid,
                    'guid': newGuid,
                    'icon': 'book',
                    'name': arcName,
                    'notes': '',
                    'sortOrder': self._arcCount,
                    'swatchColor': 'orange'
                    })
                arcCount += 1

        for srcId in source.sections:
            if source.sections[srcId].scType != 0:
                if source.sections[srcId].title in scIdsByTitle:
                    scId = scIdsByTitle[source.sections[srcId].title]
                    self.novel.sections[scId].scType = 1
                continue

            if source.sections[srcId].title in scIdsByTitle:
                scId = scIdsByTitle[source.sections[srcId].title]
            else:
                scId = create_id(self.novel.sections, prefix=SECTION_PREFIX)
                self.novel.sections[scId] = Section()
                self.novel.sections[scId].title = source.sections[srcId].title
                scIdsByTitle[self.novel.sections[scId].title] = scId
                self.novel.sections[scId].scType = source.sections[srcId].scType
                self.novel.sections[scId].scPacing = source.sections[srcId].scPacing
                newEvent = build_event(self.novel.sections[scId])
                self._jsonData['events'].append(newEvent)
            self.novel.sections[scId].status = source.sections[srcId].status

            if source.sections[srcId].scType is not None:
                self.novel.sections[scId].scType = source.sections[srcId].scType

            if source.sections[srcId].tags is not None:
                self.novel.sections[scId].tags = source.sections[srcId].tags

            if source.sections[srcId].desc is not None:
                self.novel.sections[scId].desc = source.sections[srcId].desc

            if source.sections[srcId].characters is not None:
                scCharacters = []
                for crId in source.sections[srcId].characters:
                    if crId in crIdsBySrcId:
                        scCharacters.append(crIdsBySrcId[crId])
                self.novel.sections[scId].characters = scCharacters

            if source.sections[srcId].locations is not None:
                scLocations = []
                for lcId in source.sections[srcId].locations:
                    if lcId in lcIdsBySrcId:
                        scLocations.append(lcIdsBySrcId[lcId])
                self.novel.sections[scId].locations = scLocations

            if source.sections[srcId].items is not None:
                scItems = []
                for itId in source.sections[srcId].items:
                    if itId in itIdsBySrcId:
                        scItems.append(itIdsBySrcId[itId])
                self.novel.sections[scId].items = scItems

            if source.sections[srcId].scArcs is not None:
                scArcs = []
                for acId in source.sections[srcId].scArcs:
                    if acId in acIdsBySrcId:
                        scArcs.append(acIdsBySrcId[acId])
                self.novel.sections[scId].scArcs = scArcs

            if source.sections[srcId].time is not None:
                self.novel.sections[scId].time = source.sections[srcId].time

            if source.sections[srcId].day is not None:
                dayInt = int(source.sections[srcId].day)
                sectionDelta = timedelta(days=dayInt)
                self.novel.sections[scId].date = (self.referenceDate + sectionDelta).isoformat().split('T')[0]
            elif (source.sections[srcId].date is None) and (source.sections[srcId].time is not None):
                self.novel.sections[scId].date = self.referenceDate.isoformat().split('T')[0]
            else:
                self.novel.sections[scId].date = source.sections[srcId].date

            if source.sections[srcId].lastsMinutes is not None:
                self.novel.sections[scId].lastsMinutes = source.sections[srcId].lastsMinutes
            if source.sections[srcId].lastsHours is not None:
                self.novel.sections[scId].lastsHours = source.sections[srcId].lastsHours
            if source.sections[srcId].lastsDays is not None:
                self.novel.sections[scId].lastsDays = source.sections[srcId].lastsDays


        if self._entityNarrativeGuid is None:
            self._entityNarrativeGuid = get_uid('entityNarrativeGuid')
            self._jsonData['entities'].append(
                {
                'entityType': self._typeArcGuid,
                'guid': self._entityNarrativeGuid,
                'icon': 'book',
                'name': self._entityNarrative,
                'notes': '',
                'sortOrder': self._arcCount,
                'swatchColor': 'orange'
                })
            self._arcCount += 1

        for jEvent in self._jsonData['events']:
            try:
                scId = scIdsByTitle[jEvent['title']]
            except KeyError:
                continue

            if jEvent['rangeValues'][0]['position']['timestamp'] >= self.DATE_LIMIT:
                jEvent['rangeValues'][0]['span'] = get_span(self.novel.sections[scId])
                jEvent['rangeValues'][0]['position']['timestamp'] = get_timestamp(self.novel.sections[scId])

            if self._propertyMoonphaseGuid is not None:
                eventMoonphase = get_moon_phase_plus(self.novel.sections[scId].date)
            else:
                eventMoonphase = ''

            hasMoonphase = False
            for evtVal in jEvent['values']:

                if evtVal['property'] == self._propertyDescGuid:
                    if self.novel.sections[scId].desc:
                        evtVal['value'] = self.novel.sections[scId].desc

                elif evtVal['property'] == self._propertyNotesGuid:
                    if self.novel.sections[scId].notes:
                        evtVal['value'] = self.novel.sections[scId].notes

                elif evtVal['property'] == self._propertyMoonphaseGuid:
                        evtVal['value'] = eventMoonphase
                        hasMoonphase = True

            if not hasMoonphase and self._propertyMoonphaseGuid is not None:
                jEvent['values'].append({'property': self._propertyMoonphaseGuid, 'value': eventMoonphase})

            if self.novel.sections[scId].tags:
                jEvent['tags'] = self.novel.sections[scId].tags


            newRel = []
            for evtRel in jEvent['relationships']:
                if evtRel['role'] == self._roleCharacterGuid:
                    continue

                elif evtRel['role'] == self._roleLocationGuid:
                    continue

                elif evtRel['role'] == self._roleItemGuid:
                    continue

                elif evtRel['role'] == self._roleArcGuid:
                    continue

                else:
                    newRel.append(evtRel)

            if self.novel.sections[scId].characters:
                for crId in self.novel.sections[scId].characters:
                    newRel.append(
                        {
                        'entity': self._characterGuidsById[crId],
                        'percentAllocated': 1,
                        'role': self._roleCharacterGuid,
                        })

            if self.novel.sections[scId].locations:
                for lcId in self.novel.sections[scId].locations:
                    newRel.append(
                        {
                        'entity': self._locationGuidsById[lcId],
                        'percentAllocated': 1,
                        'role': self._roleLocationGuid,
                        })

            if self.novel.sections[scId].items:
                for itId in self.novel.sections[scId].items:
                    newRel.append(
                        {
                        'entity': self._itemGuidsById[itId],
                        'percentAllocated': 1,
                        'role': self._roleItemGuid,
                        })

            if self.novel.sections[scId].scType == 0:
                newRel.append(
                    {
                    'entity': self._entityNarrativeGuid,
                    'percentAllocated': 1,
                    'role': self._roleArcGuid,
                    })

                if self.novel.sections[scId].scArcs:
                    for acId in self.novel.sections[scId].scArcs:
                        newRel.append(
                            {
                            'entity': self._arcGuidsById[acId],
                            'percentAllocated': 1,
                            'role': self._roleStorylineGuid,
                            })

            jEvent['relationships'] = newRel

        jEvents = []
        for jEvent in self._jsonData['events']:
            try:
                scId = scIdsByTitle[jEvent['title']]
            except KeyError:
                jEvents.append(jEvent)
            else:
                if not scId in self._trashEvents:
                    jEvents.append(jEvent)
        self._jsonData['events'] = jEvents
        save_timeline(self._jsonData, self.filePath)
import tkinter as tk

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
CURRENT_LANGUAGE = locale.getlocale()[0][:2]
try:
    t = gettext.translation('nv_aeon2', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

APPLICATION = 'Aeon Timeline 2'
PLUGIN = f'{APPLICATION} plugin v2.0.0'
INI_FILENAME = 'nv_aeon2.ini'
INI_FILEPATH = '.noveltree/config'


class Plugin():
    VERSION = '2.0.0'
    API_VERSION = '2.0'
    DESCRIPTION = 'Synchronize with Aeon Timeline 2'
    URL = 'https://github.com/peter88213/nv_aeon2'
    _HELP_URL = f'https://peter88213.github.io/{_("nvhelp-en")}/nv_aeon2/'

    SETTINGS = dict(
        narrative_arc='Narrative',
        property_description='Description',
        property_notes='Notes',
        property_moonphase='Moon phase',
        role_location='Location',
        role_item='Item',
        role_character='Participant',
        type_character='Character',
        type_location='Location',
        type_item='Item',
        color_section='Red',
        color_event='Yellow',
        color_point='Blue',

    )
    OPTIONS = dict(
        add_moonphase=False,
    )

    def install(self, model, view, controller, prefs):
        """Add a submenu to the main menu.
        
        Positional arguments:
            view -- reference to the NoveltreeUi instance of the application.
        """
        self._mdl = model
        self._ui = view
        self._ctrl = controller

        self._pluginMenu = tk.Menu(self._ui.mainMenu, tearoff=0)
        position = self._ui.mainMenu.index('end')
        self._ui.mainMenu.insert_cascade(position, label=APPLICATION, menu=self._pluginMenu)
        self._ui.mainMenu.entryconfig(APPLICATION, state='disabled')
        self._pluginMenu.add_command(label=_('Information'), command=self._info)
        self._pluginMenu.add_separator()
        self._pluginMenu.add_command(label=_('Update the timeline'), command=self._export_from_novx)
        self._pluginMenu.add_command(label=_('Update the project'), command=self._import_to_novx)
        self._pluginMenu.add_separator()
        self._pluginMenu.add_command(label=_('Add or update moon phase data'), command=self._add_moonphase)
        self._pluginMenu.add_separator()
        self._pluginMenu.add_command(label=_('Edit the timeline'), command=self._launch_application)

        self._ui.newMenu.add_command(label=_('Create from Aeon Timeline 2...'), command=self._create_novx)

        self._ui.helpMenu.add_command(label=_('Aeon 2 plugin Online help'), command=lambda: webbrowser.open(self._HELP_URL))

    def disable_menu(self):
        self._ui.mainMenu.entryconfig(APPLICATION, state='disabled')

    def enable_menu(self):
        self._ui.mainMenu.entryconfig(APPLICATION, state='normal')

    def _add_moonphase(self):
        """Add/update moon phase data.
        
        Add the moon phase to the event properties.
        If the moon phase event property already exists, just update.
        """
        if self._mdl.prjFile:
            timelinePath = f'{os.path.splitext(self._mdl.prjFile.filePath)[0]}{JsonTimeline2.EXTENSION}'
            if os.path.isfile(timelinePath):
                sourceDir = os.path.dirname(timelinePath)
                if not sourceDir:
                    sourceDir = '.'
                try:
                    homeDir = str(Path.home()).replace('\\', '/')
                    pluginCnfDir = f'{homeDir}/{INI_FILEPATH}'
                except:
                    pluginCnfDir = '.'
                iniFiles = [f'{pluginCnfDir}/{INI_FILENAME}', f'{sourceDir}/{INI_FILENAME}']
                configuration = Configuration(self.SETTINGS, self.OPTIONS)
                for iniFile in iniFiles:
                    configuration.read(iniFile)
                kwargs = {}
                kwargs.update(configuration.settings)
                kwargs.update(configuration.options)
                kwargs['add_moonphase'] = True
                timeline = JsonTimeline2(timelinePath, **kwargs)
                timeline.novel = Novel(tree=NvTree())
                try:
                    timeline.read()
                    timeline.write(timeline.novel)
                except Error as ex:
                    message = f'!{str(ex)}'
                else:
                    message = f'{_("File written")}: "{norm_path(timeline.filePath)}".'
                self._ui.set_status(message)

    def _create_novx(self):
        timelinePath = filedialog.askopenfilename(
            filetypes=[(JsonTimeline2.DESCRIPTION, JsonTimeline2.EXTENSION)],
            defaultextension=JsonTimeline2.EXTENSION,
            )
        if not timelinePath:
            return

        self._ctrl.close_project()
        root, __ = os.path.splitext(timelinePath)
        novxPath = f'{root}{NovxFile.EXTENSION}'
        kwargs = self._get_configuration(timelinePath)
        source = JsonTimeline2(timelinePath, **kwargs)
        target = NovxFile(novxPath)

        if os.path.isfile(target.filePath):
            self._ui.set_status(f'!{_("File already exists")}: "{norm_path(target.filePath)}".')
            return

        message = ''
        try:
            source.novel = Novel(tree=NvTree())
            source.read()
            target.novel = source.novel
            target.write()
        except Error as ex:
            message = f'!{str(ex)}'
        else:
            message = f'{_("File written")}: "{norm_path(target.filePath)}".'
            self._ctrl.open_project(filePath=target.filePath, doNotSave=True)
        finally:
            self._ui.set_status(message)

    def _edit_settings(self):
        return

    def _export_from_novx(self):
        if self._mdl.prjFile:
            timelinePath = f'{os.path.splitext(self._mdl.prjFile.filePath)[0]}{JsonTimeline2.EXTENSION}'
            if not os.path.isfile(timelinePath):
                self._ui.set_status(_('!No {} file available for this project.').format(APPLICATION))
                return

            self._ui.restore_status()
            if self._ui.ask_yes_no(_('Save the project and update the timeline?')):
                self._ctrl.save_project()
                kwargs = self._get_configuration(timelinePath)
                source = NovxFile(self._mdl.prjFile.filePath, **kwargs)
                source.novel = Novel(tree=NvTree())
                target = JsonTimeline2(timelinePath, **kwargs)
                target.novel = Novel(tree=NvTree())
                try:
                    source.read()
                    target.read()
                    target.write(source.novel)
                    message = f'{_("File written")}: "{norm_path(target.filePath)}".'
                except Error as ex:
                    message = f'!{str(ex)}'
                self._ui.set_status(message)

    def _get_configuration(self, sourcePath):
        """ Read persistent configuration data for Aeon 2 conversion.
        
        First, look for a global configuration file in the aeon2nv installation directory,
        then look for a local configuration file in the project directory.
        """
        sourceDir = os.path.dirname(sourcePath)
        if not sourceDir:
            sourceDir = '.'
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            pluginCnfDir = f'{homeDir}/{INI_FILEPATH}'
        except:
            pluginCnfDir = '.'
        iniFiles = [f'{pluginCnfDir}/{INI_FILENAME}', f'{sourceDir}/{INI_FILENAME}']
        configuration = Configuration(self.SETTINGS, self.OPTIONS)
        for iniFile in iniFiles:
            configuration.read(iniFile)
        kwargs = {}
        kwargs.update(configuration.settings)
        kwargs.update(configuration.options)
        return kwargs

    def _import_to_novx(self):
        """Update the current project from the timeline.
        
        Note:
        The NvWorkFile object of the open project cannot be used as target object.
        This is because the JsonTimeline2 source object's IDs do not match, so 
        the sections and other elements are identified by their titles when merging.
        """
        if self._mdl.prjFile:
            timelinePath = f'{os.path.splitext(self._mdl.prjFile.filePath)[0]}{JsonTimeline2.EXTENSION}'
            if not os.path.isfile(timelinePath):
                self._ui.set_status(_('!No {} file available for this project.').format(APPLICATION))
                return

            if self._ui.ask_yes_no(_('Save the project and update it?')):
                self._ctrl.save_project()
                kwargs = self._get_configuration(timelinePath)
                source = JsonTimeline2(timelinePath, **kwargs)
                target = NovxFile(self._mdl.prjFile.filePath, **kwargs)
                try:
                    target.novel = Novel(tree=NvTree())
                    target.read()
                    source.novel = target.novel
                    source.read()
                    target.novel = source.novel
                    target.write()
                    message = f'{_("File written")}: "{norm_path(target.filePath)}".'
                except Error as ex:
                    message = f'!{str(ex)}'

                self._ctrl.open_project(filePath=self._mdl.prjFile.filePath, doNotSave=True)
                self._ui.set_status(message)

    def _info(self):
        if self._mdl.prjFile:
            timelinePath = f'{os.path.splitext(self._mdl.prjFile.filePath)[0]}{JsonTimeline2.EXTENSION}'
            if os.path.isfile(timelinePath):
                try:
                    timestamp = os.path.getmtime(timelinePath)
                    if timestamp > self._mdl.prjFile.timestamp:
                        cmp = _('newer')
                    else:
                        cmp = _('older')
                    fileDate = datetime.fromtimestamp(timestamp).replace(microsecond=0).isoformat(sep=' ')
                    message = _('{0} file is {1} than the noveltree project.\n (last saved on {2})').format(APPLICATION, cmp, fileDate)
                except:
                    message = _('Cannot determine file date.')
            else:
                message = _('No {} file available for this project.').format(APPLICATION)
            messagebox.showinfo(PLUGIN, message)

    def _launch_application(self):
        if self._mdl.prjFile:
            timelinePath = f'{os.path.splitext(self._mdl.prjFile.filePath)[0]}{JsonTimeline2.EXTENSION}'
            if os.path.isfile(timelinePath):
                if self._ctrl.lock():
                    open_document(timelinePath)
            else:
                self._ui.set_status(_('!No {} file available for this project.').format(APPLICATION))

